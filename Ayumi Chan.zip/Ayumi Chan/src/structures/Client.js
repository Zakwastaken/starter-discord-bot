const { Client, Collection, GatewayIntentBits, EmbedBuilder, Partials } = require("discord.js");
const mongoose = require('mongoose');
const client = require("../configg");
const AFKS = require("../schema/afk")
const welcomeData = require("../schema/welcome");
const welcomemsg = require("../schema/joinmsg");
const byeData = require("../schema/leavechannel");
const byemsg = require("../schema/leavemessage");
const autoResponse = require("../schema/autoresponse");
const autoResponseCooldown = new Set();
const moment = require('moment');
const Lavamusic = require('./Lavamusic');

class MusicBot extends Client {
  constructor() {
    super({
      allowedMentions: {
        everyone: false,
        roles: false,
        users: false
      },
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildIntegrations,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildMessageTyping,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.DirectMessageReactions,
        GatewayIntentBits.DirectMessageTyping,

      ],
      partials: [Partials.Channel, Partials.Message, Partials.User, Partials.GuildMember, Partials.Reaction]
    });
    this.on('messageCreate', async message => {
      let data2;
      try {
        data2 = await AFKS.findOne({
          userId: message.author.id,
          guildId: message.guild.id,
        })
        if (!data2) {
          data2 = await AFKS.create({
            userId: message.author.id,
            guildId: message.guild.id,
          })
        }
      } catch (error) {
      }
    
      if (data2.AFK === true) {
        data2.AFK_Reason = null
        data2.AFK = false
        message.channel.send(`_\`\`\`fix\nWelcome again ${message.member.user.username}, I removed your [ AFK ] status!\`\`\`_`)
        await data2.save()
      }
      if (message.mentions.members.first()) {
        let data3;
        try {
          data3 = await AFKS.findOne({
            userId: message.mentions.members.first().id,
            guildId: message.guild.id,
          })
          if (!data3) {
            data3 = await AFKS.create({
              userId: message.mentions.members.first().id,
              guildId: message.guild.id,
            })
          }
        } catch (error) {
        }
    
        if (data3.AFK == true) {
          message.channel.send(`<a:correct:1004239653072801922>➜ **${message.mentions.members.first().user.tag}** is currently **AFK** for reason ***${data3.AFK_Reason || "nothing."}***`)
        }
      }
    });
    this.on('guildMemberAdd', async (member) => {
      const userAvatar = member.user.displayAvatarURL({
        dynamic: true,
        size: 512,
      });
      const data = await welcomeData.findOne({
        GuildID: member.guild.id,
      });
      if (data) {
        const data2 = await welcomemsg.findOne({
          GuildID: member.guild.id,
        });
        if (data2) {
          var joinmessage = data2.JoinMsg;
     
          joinmessage = joinmessage.replace("{user.mention}", `${member}`);
          joinmessage = joinmessage.replace("{user.name}", `${member.user.tag}`);
          joinmessage = joinmessage.replace("{server}", `${member.guild.name}`);
          joinmessage = joinmessage.replace(
            "{membercount}",
            `${member.guild.memberCount}`
          );
     
          let embed = new EmbedBuilder()
            .setDescription(joinmessage)
            .setThumbnail(userAvatar)
            .setColor(client.embedColor)
     
          let channel = data.Welcome;
     
          member.guild.channels.cache.get(channel).send({embeds: [embed]});
          
        } else if (!data2) {
          let embed2 = new EmbedBuilder()
          .setAuthor({ name: `User Join!`, iconURL: member.user.avatarURL()})
          .setThumbnail(userAvatar)
          .setDescription(
            `<@${member.user.id}>\n_\`\`\`asciidoc\nWelcome To [ ${member.guild.name} ] Server!\`\`\`_`
          )
          .addFields([{ name: "⏰ __**Age Of Accounts**__ :", value: `\`\`\`${member.user.createdAt}.\`\`\``}])
          .setFooter({
            text: `We Now Have ${member.guild.memberCount} User!`
            })
          .setColor(client.embedColor)
          .setTimestamp()
          
          let channel = data.Welcome
     
         member.guild.channels.cache.get(channel).send({ embeds: [embed2] });
          }}})
          this.on('guildMemberRemove', async (member) => {
            const userAvatar = member.user.displayAvatarURL({
              dynamic: true,
              size: 512,
            });
            const data = await byeData.findOne({
              GuildID: member.guild.id,
            });
            if (data) {
              const data2 = await byemsg.findOne({
                GuildID: member.guild.id,
              });
              if (data2) {
                var leavemessage = data2.ByeMsg;
           
                leavemessage = leavemessage.replace("{user.mention}", `${member}`);
                leavemessage = leavemessage.replace("{user.name}", `${member.user.tag}`);
                leavemessage = leavemessage.replace("{server}", `${member.guild.name}`);
                leavemessage = leavemessage.replace(
                  "{membercount}",
                  `${member.guild.memberCount}`
                );
           
                let embed = new EmbedBuilder()
                  .setDescription(`${leavemessage}`)
                  .setThumbnail(userAvatar)
                  .setColor(client.embedColor)
          
                let channel = data.Bye;
           
                member.guild.channels.cache.get(channel).send({embeds: [embed]});
              } else if (!data2) {
                let embed2 = new EmbedBuilder()
                .setAuthor({ name: `User Left!`, iconURL: member.user.avatarURL()})
                  .setThumbnail(member.user.avatarURL())
                  .setDescription(
                   `<@${member.user.id}>\n_\`\`\`asciidoc\nGoodbye from [ ${member.guild.name} ] Server!\`\`\`_`
                 )
                 .addFields([{ name: "⏰ __**Age Of Accounts**__ :", value: `\`\`\`${member.user.createdAt}.\`\`\``}])
                 .setFooter({
                  text: `We Now Have ${member.guild.memberCount} User!`
                  })
                  .setColor(client.embedColor)
                  .setTimestamp()
           
                let byechannel = data.Bye;
           
                member.guild.channels.cache.get(byechannel).send({embeds: [embed2]});
              }}})
              this.on('messageCreate', async(message) => {
                const autoResponseSettings = await autoResponse.find({
                  guildId: message.guild.id,
                });
          
                if (autoResponseSettings.length > 1) {
                  for (let i = 1; i < autoResponseSettings.length; i++) {
                    if (
                      message.content.toLowerCase() == autoResponseSettings[i].name.toLowerCase()
                    ) {
                      if (autoResponseCooldown.has(message.author.bot)) {
                        return message.channel.send(
                          `\`\`\`asciidoc\nSlow Down!\`\`\``
                        );
                      } else {
                        message.channel.send(
                          autoResponseSettings[i].content
                            .replace(/{user}/g, `${message.author}`)
          
                            .replace(/{user_tag}/g, `${message.author.tag}`)
                            .replace(/{user_name}/g, `${message.author.username}`)
                            .replace(/{user_ID}/g, `${message.author.id}`)
                            .replace(/{guild_name}/g, `${message.guild.name}`)
                            .replace(/{guild_ID}/g, `${message.guild.id}`)
                            .replace(/{memberCount}/g, `${message.guild.memberCount}`)
                            .replace(/{size}/g, `${message.guild.memberCount}`)
                            .replace(/{guild}/g, `${message.guild.name}`)
                            .replace(
                              /{member_createdAtAgo}/g,
                              `${moment(message.author.createdTimestamp).fromNow()}`
                            )
                            .replace(
                              /{member_createdAt}/g,
                              `${moment(message.author.createdAt).format(
                                "MMMM Do YYYY, h:mm:ss a"
                              )}`
                            )
                        );
                        autoResponseCooldown.add(message.author.id);
                        setTimeout(() => {
                          autoResponseCooldown.delete(message.author.id);
                        }, 2000);
                        break;
                      }
                    }
                  }
                } }) 
    this.commands = new Collection();
    this.slashCommands = new Collection();
    this.config = require("../configg.js");
    this.owner = this.config.ownerID;
    this.prefix = this.config.prefix;
    this.embedColor = this.config.embedColor;
    this.aliases = new Collection();
    this.commands = new Collection();
    this.logger = require("../utils/logger.js");
    this.emoji = require("../utils/emoji.json");
    if (!this.token) this.token = this.config.token;
    this.manager = new Lavamusic(this)

    this.rest.on('rateLimited', (info) => {
      this.logger.log('ratelimit', "log");
    })

    /**
     *  Mongose for data base
     */
    const dbOptions = {
      useNewUrlParser: true,
      autoIndex: false,
      connectTimeoutMS: 10000,
      family: 4,
      useUnifiedTopology: true,
    };
    mongoose.connect(this.config.mongourl, dbOptions);
    mongoose.Promise = global.Promise;
    mongoose.connection.on('connected', () => {
      this.logger.log('[DB] DATABASE CONNECTED', "ready");
    });
    mongoose.connection.on('err', (err) => {
      console.log(`Mongoose connection error: \n ${err.stack}`, "error");
    });
    mongoose.connection.on('disconnected', () => {
      console.log('Mongoose disconnected');
    });

    ['commands','events'].forEach((handler) => {
      require(`../handlers/${handler}`)(this);
    });
  }
  connect() {
    return super.login(this.token);
  };
};

module.exports = MusicBot;
