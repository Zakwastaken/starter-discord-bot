require("dotenv").config();

module.exports = {
    token: process.env.TOKEN || "Nzg4NjEwMDQyMTkzNzcyNjI1.Ga2FT3.qQpK66pHmJCyMBv0BKPfT7pQ0yNBP2yd6xzSLo",  // your bot token
    clientID: process.env.CLIENT_ID || "788204377634635806", // your bot client id
    prefix: process.env.PREFIX || "y.", // bot prefix
    ownerID: process.env.OWNERID || "760723665372971008", //your discord id
    IconURL:
    "https://cdn.discordapp.com/attachments/999994143029870622/1000333480414171176/disc.gif",
    SpotifyID: process.env.SPOTIFYID || "ad302a75ba9841c7b6dcd1386698ea8d",
    SpotifySecret: process.env.SPOTIFYSECRET || "6dd937898e7a4af09a0bc2268493a6a8",
    mongourl: process.env.MONGO_URI || "mongodb+srv://youtube:youtube123@cluster0.hmgwx.mongodb.net/Data", // MongoDb URL
    embedColor: process.env.COlOR || 0x76B947, // embed colour
    logs: process.env.LOGS || "974187582558724126", // channel id for guild create and delete logs
    links: {
        img: process.env.IMG || 'https://media.discordapp.net/attachments/963097935820750878/983300268131225651/20220606_145403.png', //setup system background image 
        support: process.env.SUPPORT || 'https://discord.gg/BqECPaZP', //support server invite link
        invite: process.env.INVITE || 'https://discord.com/oauth2/authorize?client_id=788204377634635806&permissions=8&scope=bot%20applications.commands' //bot invite link
    },
    nodes: [
        {
            host: process.env.NODE_HOST || "lava.link",
            identifier: process.env.NODE_ID || "AyumiChan.xyz",
            port: parseInt(process.env.NODE_PORT || "80"),
            password: process.env.NODE_PASSWORD || "youshallnotpass",
            secure: parseBoolean(process.env.NODE_SECURE || "false"),

        }
    ],

}

function parseBoolean(value) {
    if (typeof (value) === 'string') {
        value = value.trim().toLowerCase();
    }
    switch (value) {
        case true:
        case "true":
            return true;
        default:
            return false;
    }
}
