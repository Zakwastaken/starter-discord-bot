function blackjackSum(hand) {
    let sum = 0;
    let counterA = 0;
    for (let i = 0; i < hand.length; i++) {
        if (hand[i] === "A") {
            sum = sum + 1;
            counterA++;
        } else if ((hand[i] === "K") || (hand[i] === "Q") || (hand[i] === "J")) {
            sum = sum + 10;
        } else {
            sum = sum + parseInt(hand[i]);
        }
    }
    if (counterA > 0) {
        let condition = true
        while (condition) {
            if (sum > 11) {
                condition = false
            } else if (sum <= 10) {
                sum = sum + 10;
            }
        }
    }
    return sum;

}

//blackjack helper function to get a random card
function blackjackHelper() {
    let shape = [':clubs:', ':hearts:', ':diamonds:', ':spades:']
    let numbers = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];
    let guessNumber = (Math.random() * 12).toFixed(0);
    let randomShape = (Math.random() * 3).toFixed(0);
    let returnNumber = numbers[parseFloat(guessNumber)];
    let returnShape = shape[parseFloat(randomShape)];
    return {
        number: returnNumber,
        shape: returnShape
    }

}