const mongoose = require("mongoose")

const AFKSchema = mongoose.Schema({
    userId: {
        type: String,
        required: true
    },
    guildId: {
        type: String,
        required: true
    },
    AFK: {
        type: Boolean,
        default: false,
    },
    AFK_Reason: {
        type: String,
        default: null
    }
})

const MessageModel = module.exports = mongoose.model("afk", AFKSchema)