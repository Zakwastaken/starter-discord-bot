const jobs = ['Miner', 'Fisherman', 'Builder', 'Hunter', 'Police', 'Maid', 'Chef', 'Logger'];
const economyUser = require('../../schema/economy');
const { EmbedBuilder } = require("discord.js");
const ms = require('ms');
const logChannel = "974187582558724126";

const COOLDOWN = 1 * 60 * 1000;

const randomNum = (max, min) => Math.floor(Math.random() * (max - (min ? min : 0))) + (min ? min : 0);
const addMoney = async (userID, cash = 0) => {
	await economyUser.updateOne(
		{ userID },
		{ $set: { userID, 'cooldowns.WORK': Date.now() + COOLDOWN }, $inc: { cash } },
		{ upsert: true }
	);
};

module.exports = {
	name: 'work',
	description: 'Work and make money.',
	category: 'Economy',

    execute: async (message, args, client, prefix) => {
		const loggerchannel = client.channels.cache.get(logChannel);
		const user =
		message.mentions.users.first() ||
		client.users.cache.filter((user) => user.username).get(args[0]) ||
		client.users.cache.filter((user) => user.tag).get(args[0]) ||
		client.users.cache.filter((user) => user.id).get(args[0]) ||
		message.author;
		const data = await economyUser.findOne({ userID: message.author.id });
		if (!data && user.id === message.author.id) return message.reply({ content: `\`\`\`asciidoc\nYou are not yet registered to the economy system, ${prefix}register to register yourself.\`\`\``})
		if (!data) return message.reply({ content: `\`\`\`asciidoc\nThis user is not registered to the economy system, ${prefix}register\`\`\`` })
		if (data?.cooldowns?.WORK > Date.now()) {
            const warning = new EmbedBuilder()
			.setColor("#b30000")
			.setDescription(`<a:timer:1044486802351861880>➜ No! **${message.author.username},** You must wait **${ms(data.cooldowns.WORK - Date.now())}.**`)
			return message.reply({ embeds: [warning] }).then((msg) => {
				let time = "5s";
				setTimeout(function () {
				  msg.delete();
				}, ms(time));
			  });
		} 
		const earning = randomNum(1000, 10000);
		const job = jobs[randomNum(jobs.length)];
		await addMoney(message.author.id, earning);
        const intro = new EmbedBuilder()
        .setColor(client.embedColor)
        .setDescription(`<a:dc_loading:1043066228568231996>➜ ***${message.author.username} start working for a while...***`)
        message.reply({embeds: [intro]}).then((msg) => {
            let time = "3s";
            setTimeout(function () {
              msg.edit({
                content: "\`\`\`asciidoc\nThis is the result!\`\`\`",
                embeds: [embed]
              });
            }, ms(time))
          });
        const embed = new EmbedBuilder()
		.setColor(client.embedColor)
        .setFooter({text: `Player ID: ${message.author.id}`})
		.setTimestamp()
		.setDescription(`<a:money:1044474108739592294>➜ ***${message.author.username}, You worked as a ${job}.***\n<:line:972780438118629386> **Total Earned:** <:ayumi_cash:1044447888413040680> __**${earning.toLocaleString()}**__`);

		const embedlog = new EmbedBuilder()
		.setColor(client.embedColor)
		.setAuthor({ name: "𝘌𝘤𝘰𝘯𝘰𝘮𝘺 𝘊𝘢𝘵𝘦𝘨𝘰𝘳𝘪𝘦𝘴.", iconURL: "https://cdn.discordapp.com/emojis/1044581691047546930.webp?size=96&quality=lossless"})
		.setDescription(`\`\`\`asciidoc\n${message.author.username}#${message.author.discriminator} used the commands [ work ] in [ ${message.guild.name} ]\`\`\``)
		loggerchannel.send({ embeds: [embedlog] });
	}
};