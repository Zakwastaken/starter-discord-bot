const eco = require('../../schema/economy');
const { EmbedBuilder } = require("discord.js");
const ms = require('ms');
const logChannel = "974187582558724126";

module.exports = {
    name: 'beg',
    category: "Economy",
    description: 'description',
    usage: 'usage',
    aliases: [],
    cooldown: 10,
    boostersOnly: false,
    // cooldownMsg: {title: "Slow Down!", description: "> You can use this command every **${timecommand}**!\n> Try again in: **${timeleft}**", color: "RED"},
    execute: async (message, args, client, prefix) => {
      const loggerchannel = client.channels.cache.get(logChannel);
      const user =
      message.mentions.users.first() ||
      client.users.cache.filter((user) => user.username).get(args[0]) ||
      client.users.cache.filter((user) => user.tag).get(args[0]) ||
      client.users.cache.filter((user) => user.id).get(args[0]) ||
      message.author;
      message.author;
	  const data = await eco.findOne({ userID: message.author.id });
	  if (!data && user.id === message.author.id) return message.reply({ content: `\`\`\`asciidoc\nYou are not yet registered to the economy system, ${prefix}register to register yourself.\`\`\``})
	  if (!data) return message.reply({ content: `\`\`\`asciidoc\nThis user is not registered to the economy system, ${prefix}register\`\`\`` })
    let desc
    let chances = Math.floor(Math.random() * 3) >= 2 ? true : false
    if(chances == true) {
      let amount = Math.floor(Math.random() * (1+1500-400) + 400)
      desc = [
        `"Here take <:ayumi_cash:1044447888413040680> __**${amount.toLocaleString()}**__"`,
        `"Aww u poor little beggar, take <:ayumi_cash:1044447888413040680> __**${amount.toLocaleString()}**__"`,
        `"Here take this <:ayumi_cash:1044447888413040680> __**${amount.toLocaleString()}**__"`,
        `"Here take this <:ayumi_cash:1044447888413040680> __**${amount.toLocaleString()}**__ cash."`,
        `You got <:ayumi_cash:1044447888413040680> __**${amount.toLocaleString()}**__ for begging.`,
        `Imagine begging and got <:ayumi_cash:1044447888413040680> __**${amount.toLocaleString()}**__`,
        `Woah u begged and got <:ayumi_cash:1044447888413040680> __**${amount.toLocaleString()}**__`,
        `You begged at stranger and got <:ayumi_cash:1044447888413040680> __**${amount.toLocaleString()}**__`,
        `You begged from a begger and got <:ayumi_cash:1044447888413040680> __**${amount.toLocaleString()}**__`
      ]
    let profile;
    try {
      profile = await eco.findOne({
        userID: message.author.id,
      })
      if(!profile) {
        profile = await eco.create({
          userID: message.author.id,
          cash: 0,
          balance: 0
        })
        profile.save()
      }
    } catch (e) {
      console.error(e)
    }
    try {
    await eco.findOneAndUpdate(
        {
          userID: message.author.id,
        },
        {
          $inc: {
            cash: amount,
          },
        }
      );
    } catch (err) {
      console.log(err);
    }
    } else {
      let amount = Math.floor(Math.random() * (1+1500-400) + 400)
      desc = [
        `Imagine begging.`,
        `Lmao u get nothing.`,
        `Ewww imagine begging for cash.`,
        `"No."`,
        `You begged and you got nothing!`,
        `You got nothing from begging lol!`,
        `Go get a life! stop begging!`,
        `"Ew beggars! Go away!"`,
        `"Here take this <:ayumi_cash:1044447888413040680> __**${amount.toLocaleString()}**__, You get nothing!"`,
        `Stop begging!`,
        `"Get a job and earn your own money!"`
      ]
    }
    const intro = new EmbedBuilder()
    .setColor(client.embedColor)
    .setDescription(`<a:dc_loading:1043066228568231996>➜ ***${message.author.username} start begging for a while...***`)
    message.reply({embeds: [intro]}).then((msg) => {
        let time = "3s";
        setTimeout(function () {
          msg.edit({
            content: "\`\`\`asciidoc\nThis is the result!\`\`\`",
            embeds: [embed]
          });
        }, ms(time))
      });
    let embed = new EmbedBuilder()
    .setDescription(`<:ayumi_please:951674458450563093>➜ ${desc[Math.floor(Math.random() * desc.length)]}`)
		.setColor(client.embedColor)
    .setFooter({text: `Player ID: ${message.author.id}`})
		.setTimestamp()

    const embedlog = new EmbedBuilder()
		.setColor(client.embedColor)
		.setAuthor({ name: "𝘌𝘤𝘰𝘯𝘰𝘮𝘺 𝘊𝘢𝘵𝘦𝘨𝘰𝘳𝘪𝘦𝘴.", iconURL: "https://cdn.discordapp.com/emojis/1044581691047546930.webp?size=96&quality=lossless"})
		.setDescription(`\`\`\`asciidoc\n${message.author.username}#${message.author.discriminator} used the commands [ beg ] in [ ${message.guild.name} ]\`\`\``)
		loggerchannel.send({ embeds: [embedlog] });

}
      }