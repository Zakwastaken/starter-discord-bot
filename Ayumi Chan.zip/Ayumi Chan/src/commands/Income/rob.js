const economyUser = require('../../schema/economy');
const { EmbedBuilder } = require("discord.js");
const ms = require('ms');
const logChannel = "974187582558724126";

const addMoney = async (userID, cash = 0) => economyUser.updateOne({ userID }, { $set: { userID }, $inc: { cash } }, { upsert: true });
const robMoney = async (userID, cash = 0) => {
	await economyUser.updateOne(
		{ userID },
		{ $inc: { cash: -cash } },
		{ upsert: true }
	);
};

module.exports = {
	name: 'rob',
	description: 'Rob someone elses current balance.',
	usage: '<user> <amount>',
    cooldown: 3600,
	category: 'Economy',
	aliases: ['rb', 'r'],
    execute: async (message, args, client, prefix) => {
		const loggerchannel = client.channels.cache.get(logChannel);
		const user =
		message.mentions.users.first() ||
		client.users.cache.filter((user) => user.username).get(args[0]) ||
		client.users.cache.filter((user) => user.tag).get(args[0]) ||
		client.users.cache.filter((user) => user.id).get(args[0]) ||
		message.author;
		message.author;
		const data = await economyUser.findOne({ userID: message.author.id });
		if (!data && user.id === message.author.id) return message.reply({ content: `\`\`\`asciidoc\nYou are not yet registered to the economy system, ${prefix}register to register yourself.\`\`\``})
		if (!data) return message.reply({ content: `\`\`\`asciidoc\nThis user is not registered to the economy system, ${prefix}register\`\`\`` })

          const member = message.mentions.users.first() || client.users.cache.get(args[0]);
          if (!member) return message.reply('\`\`\`asciidoc\n⚠️➜ You must mention someone!\`\`\`');

		  if (member.id === message.author.id) return message.reply({ content: `\`\`\`fix\nHey stupid, seems pretty dumb to steal from yourself -_-\`\`\`` })

		const memberBank = await economyUser.findOne({ userID: member.id });
		const memberCash = memberBank && memberBank.cash ? memberBank.cash : 0;
		const robbed = Math.floor((memberCash * 40) / 100);

		if (robbed === 0) {
			return message.reply('\`\`\`asciidoc\n⚠️➜ This user has 0 in cash!\`\`\`');
		}

		await robMoney(member.id, robbed);
		await addMoney(message.author.id, robbed);
        const embed = new EmbedBuilder()
		.setColor(client.embedColor)
		.setDescription(`<a:correct:1004239653072801922>➜ ***${message.author.username}, Successfully robbed from ${member.username}.***\n<:line:972780438118629386> **Total Earned:** <:ayumi_cash:1044447888413040680> __**${robbed.toLocaleString()}**__`)
        .setFooter({text: `Player ID: ${message.author.id}`})
		.setTimestamp()
        message.reply({ embeds: [embed] });

		const embedlog = new EmbedBuilder()
		.setColor(client.embedColor)
		.setAuthor({ name: "𝘌𝘤𝘰𝘯𝘰𝘮𝘺 𝘊𝘢𝘵𝘦𝘨𝘰𝘳𝘪𝘦𝘴.", iconURL: "https://cdn.discordapp.com/emojis/1044581691047546930.webp?size=96&quality=lossless"})
		.setDescription(`\`\`\`asciidoc\n${message.author.username}#${message.author.discriminator} used the commands [ rob ] in [ ${message.guild.name} ]\`\`\``)
		loggerchannel.send({ embeds: [embedlog] });
	}
};