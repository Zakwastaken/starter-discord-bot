const { EmbedBuilder } = require("discord.js");

module.exports = {
  	name: "remove",
    category: "Music",
  	description: "Remove a song from the queue.",
	args: true,
    usage: "<Number of song in queue>",
    userPerms: [],
    dj: true,
    owner: false,
    player: true,
    inVoiceChannel: true,
    sameVoiceChannel: true,
	 execute: async (message, args, client, prefix) => {
  
		const player = client.manager.get(message.guild.id);

        if (!player.queue.current) {
            let thing = new EmbedBuilder()
                .setColor("#b30000")
                .setDescription("⚠️➜ There is no music playing.");
            return message.reply({embeds: [thing]});
        }

    const position = (Number(args[0]) - 1);
       if (position > player.queue.size) {
        const number = (position + 1);
         let thing = new EmbedBuilder()
            .setColor("#b30000")
            .setDescription(`> No Songs At Number:\n\`${number}\`.\n> Total Songs:\n\`${player.queue.size}\``);
            return message.reply({embeds: [thing]});
        }

    const song = player.queue[position]
		player.queue.remove(position);

		const emojieject = client.emoji.remove;

		let thing = new EmbedBuilder()
			.setColor(client.embedColor)
            .setAuthor({ name: "➜ Clear Song.", iconURL: client.config.IconURL})
			.setDescription(`**[${song.title}](${song.uri})**`)
		  return message.reply({embeds: [thing]});
	
    }
};
