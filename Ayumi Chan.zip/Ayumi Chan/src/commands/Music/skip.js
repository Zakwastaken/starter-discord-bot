const { EmbedBuilder } = require("discord.js");

module.exports = {
	name: "skip",
	aliases: ["s"],
	category: "Music",
	description: "Skip the currently playing song.",
	args: false,
  usage: "",
  userPerms: [],
  dj: true,
  owner: false,
  player: true,
  inVoiceChannel: true,
  sameVoiceChannel: true,
execute: async (message, args, client, prefix) => {
  
		const player = message.client.manager.get(message.guild.id);

        if (!player.queue.current) {
            let thing = new EmbedBuilder()
                .setColor("#b30000")
                .setDescription("\`\`\`⚠️➜ There is no music playing.\`\`\`");
         return message.reply({embeds: [thing]});
        }
        const song = player.queue.current;

           player.stop();
           
		const emojiskip = message.client.emoji.skip;

		let thing = new EmbedBuilder()
    .setAuthor({ name: "➜ Song Skipped.", iconURL: client.config.IconURL})
    .setDescription(`**[${song.title}](${song.uri})**`)
			.setColor(message.client.embedColor)
		return message.reply({embeds: [thing]}).then(msg => { setTimeout(() => {msg.delete()}, 3000);
       })
	
    }
};
