const { EmbedBuilder } = require("discord.js");

module.exports = {
  	name: "stop",
    category: "Music",
    description: "Stops the music.",
    args: false,
    usage: "",
    userPerms: [],
    dj: true,
    owner: false,
    player: true,
    inVoiceChannel: true,
    sameVoiceChannel: true,
	execute: async (message, args, client, prefix) => {
  
        const player = client.manager.get(message.guild.id);

        if (!player.queue.current) {
            let thing = new EmbedBuilder()
                .setColor("#b30000")
                .setDescription("\`\`\`⚠️➜ There is no music playing.\`\`\`");
            return message.reply({embeds: [thing]});
        }

        const autoplay = player.get("autoplay")
        if (autoplay === true) {
            player.set("autoplay", false);
        }

        player.stop();
        player.queue.clear();

        const emojistop = client.emoji.stop;

		    let thing = new EmbedBuilder()
            .setColor(client.embedColor)
            .setDescription(`\`\`\`${emojistop} ➜ Stopped the music.\`\`\``)
        message.reply({embeds: [thing]});
	
  	}
};
