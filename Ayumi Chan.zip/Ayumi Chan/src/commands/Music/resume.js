const { EmbedBuilder } = require("discord.js");

module.exports = {
	name: "resume",
    aliases: ["r"],
    category: "Music",
    description: "Resume currently playing music.",
    args: false,
    usage: "<Number of song in queue>",
    userPerms: [],
    dj: true,
    owner: false,
    player: true,
    inVoiceChannel: true,
    sameVoiceChannel: true,
 execute: async (message, args, client, prefix) => {
  
		const player = client.manager.get(message.guild.id);
        const song = player.queue.current;

        if (!player.queue.current) {
            let thing = new EmbedBuilder()
                .setColor("#b30000")
                .setDescription("\`\`\`⚠️➜ There is no music playing.\`\`\`");
            return message.reply({embeds: [thing]});
        }

        const emojiresume = client.emoji.resume;

        if (!player.paused) {
            let thing = new EmbedBuilder()
                .setColor("#b30000")
                .setDescription(`\`\`\`${emojiresume} ➜ The player is already resumed.\`\`\``)
          return message.reply({embeds: [thing]});
        }

        player.pause(false);

        let thing = new EmbedBuilder()
            .setAuthor({ name: "➜ Song Continued.", iconURL: client.config.IconURL})
            .setDescription(`**[${song.title}](${song.uri})**`)
            .setColor(client.embedColor)
        return message.reply({embeds: [thing]});
	
    }
};
