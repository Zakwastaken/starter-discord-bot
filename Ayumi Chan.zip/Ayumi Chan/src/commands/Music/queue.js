
const { Client, Message, EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require("discord.js");
const load = require('lodash');
const { convertTime } = require('../../utils/convert.js');

module.exports = {
    name: "queue",
    category: "Music",
    aliases: ["q"],
    description: "Show the music queue and now playing.",
    args: false,
    usage: "",
    userPerms: [],
    owner: false,
    player: true,
    inVoiceChannel: false,
    sameVoiceChannel: false,
   execute: async (message, args, client, prefix) => {
  
            const player = client.manager.get(message.guild.id);
       const queue = player.queue;  
       
           if (!player.queue.current)
      return message.reply({
        content: `\`\`\`⚠️➜ Please start a song before doing this action!\`\`\``,
      });
   if(!player) return message.channel.send({ embeds: [new EmbedBuilder().setColor(client.embedColor).setTimestamp().setDescription(`\`\`\`⚠️➜ Nothing is playing right now.\`\`\``)]});
            
            if(!player.queue) return message.channel.send({ embeds: [new EmbedBuilder().setColor(client.embedColor).setTimestamp().setDescription(`\`\`\`⚠️➜ Nothing is playing right now.\`\`\``)]});
           
            if(player.queue.length === "0" || !player.queue.length) {
                const embed = new EmbedBuilder()
                .setColor(client.embedColor)
                .setAuthor({ name: "➜ Song Played.", iconURL: client.config.IconURL})
                .setDescription(`**[${player.queue.current.title}](${player.queue.current.uri})** • \`[${convertTime(queue.current.duration)}]\` • **[${player.queue.current.requester}]**`)

                await message.channel.send({
                    embeds: [embed]
                }).catch(() => {});
            } else {
                const queuedSongs = player.queue.map((t, i) => `\`${++i}\` • **${t.title}** • \`[${convertTime(t.duration)}]\``);

                const mapping = load.chunk(queuedSongs, 10);
                const pages = mapping.map((s) => s.join("\n"));
                let page = 0;

                if(player.queue.size < 11) {
                    const embed = new EmbedBuilder()
                    .setColor(client.embedColor)
                    .setDescription(`**Song:**\n > **[${player.queue.current.title}](${player.queue.current.uri})** • \`[${convertTime(queue.current.duration)}]\`  • **[${player.queue.current.requester}]**\n\n**Queued Songs:**\n${pages[page]}`)
                    .setFooter({ text: `Page ${page + 1}/${pages.length}`, iconURL: message.author.displayAvatarURL({ dynamic: true })})
                    .setThumbnail(player.queue.current.thumbnail)
                    .setAuthor({ name: `» ${message.guild.name} Server.`, iconURL: client.config.IconURL})

                    await message.channel.send({
                        embeds: [embed]
                    })
                } else {
                    const embed2 = new EmbedBuilder()
                    .setColor(client.embedColor)
                    .setDescription(`**Song:**\n > **[${player.queue.current.title}](${player.queue.current.uri})** • \`[${convertTime(queue.current.duration)}]\`  • **[${player.queue.current.requester}]**\n\n**Queued Songs:**\n${pages[page]}`)
                    .setFooter({ text: `Executed By ${message.author.tag}`, iconURL:  message.author.displayAvatarURL({ dynamic: true })})
                    .setImage(player.queue.current.thumbnail)
                    .setAuthor({ name: `» ${message.guild.name} Server.`, iconURL: client.config.IconURL})

                    const but1 = new ButtonBuilder()
                    .setCustomId("queue_cmd_but_1")
                  
                    .setEmoji("⏭")
                    .setStyle(ButtonStyle.Primary)

                    const but2 = new ButtonBuilder()
                    .setCustomId("queue_cmd_but_2")
                    .setEmoji("⏮")
                    .setStyle(ButtonStyle.Primary)

                    const but3 = new ButtonBuilder()
                    .setCustomId("queue_cmd_but_3")
                    .setLabel(`${page + 1}/${pages.length}`)
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true)

                    const row1 = new ActionRowBuilder().addComponents([
                        but2, but3, but1
                    ]);

                    const msg = await message.channel.send({
                        embeds: [embed2],
                        components: [row1]
                    })

                    const collector = message.channel.createMessageComponentCollector({
                        filter: (b) => {
                            if(b.user.id === message.author.id) return true;
                            else {
                                b.reply({
                                    ephemeral: true,
                                    content: `\`\`\`⚠️➜ You can't use this button!\`\`\``
                                });
                                return false;
                            };
                        },
                        time: 60000*5,
                        idle: 30e3
                    });

                    collector.on("collect", async (button) => {
                        if(button.customId === "queue_cmd_but_1") {
                            await button.deferUpdate().catch(() => {});
                            page = page + 1 < pages.length ? ++page : 0;

                            const embed3 = new EmbedBuilder()
                            .setColor(client.embedColor)
                            .setDescription(`**[${player.queue.current.title}](${player.queue.current.uri})** • \`[${convertTime(queue.current.duration)}]\` • **[${player.queue.current.requester}]**\n\n**Queued Songs:**\n${pages[page]}`)
                            .setFooter({ text: `Executed By ${message.author.tag}`, iconURL:  message.author.displayAvatarURL({ dynamic: true })})
                            .setImage(player.queue.current.thumbnail)
                            .setAuthor({ name: `» ${message.guild.name} Server.`, iconURL: client.config.IconURL})

                            await msg.edit({
                                embeds: [embed3],
                                components: [new ActionRowBuilder().addComponents(but2, but3.setLabel(`Page ${page + 1}/${pages.length}`), but1)]
                            })
                        } else if(button.customId === "queue_cmd_but_2") {
                            await button.deferUpdate().catch(() => {});
                            page = page > 0 ? --page : pages.length - 1;

                            const embed4 = new EmbedBuilder()
                            .setColor(client.embedColor)
                            .setDescription(`**[${player.queue.current.title}](${player.queue.current.uri})** • \`[${convertTime(queue.current.duration)}]\` • **[${player.queue.current.requester}]**\n\n**Queued Songs:**\n${pages[page]}`)
                            .setFooter({ text: `Executed By ${message.author.tag}`, iconURL:  message.author.displayAvatarURL({ dynamic: true })})
                           .setImage(player.queue.current.thumbnail)
                           .setAuthor({ name: `» ${message.guild.name} Server.`, iconURL: client.config.IconURL})


                            await msg.edit({
                                embeds: [embed4],
                                components: [new ActionRowBuilder().addComponents(but2, but3.setLabel(`Page ${page + 1}/${pages.length}`), but1)]
                 }).catch(() => {});
                        } else return;
                    });

                    collector.on("end", async () => {
                        await msg.edit({
                            components: []
                        })
                    });
                }
            }
       }
  };
