const slotItems = ["<:ayumi:986185601453785098>", "<:ayumi_cash:1044447888413040680>", "🍌", "🍎", "🍒"];
let { EmbedBuilder } = require("discord.js")
const currency = require('../../schema/economy');
const ms = require('ms');

module.exports = {
        name:"slots",
        aliases: ["sl"],
        category: "Economy",
        description: "Slot game | 3x - rare | 3x - common.",
        usage: "<amount>",
        cooldown: 10,
        accessableby: "everyone",
        execute: async (message, args, client, prefix) => { 
            const user =
    message.mentions.users.first() ||
    client.users.cache.filter((user) => user.username).get(args[0]) ||
    client.users.cache.filter((user) => user.tag).get(args[0]) ||
    client.users.cache.filter((user) => user.id).get(args[0]) ||
    message.author;
    let profile = await currency.findOne({
        userID: message.author.id,
      })
     if(!profile) {
        if (!profile && user.id === message.author.id) return message.reply({ content: `\`\`\`asciidoc\nYou are not yet registered to the economy system, ${prefix}register to register yourself.\`\`\``})
     }

 let amountToBet = args
 let max = 150000;
 if (profile.cash < amountToBet) {
  return message.reply({ content: `\`\`\`asciidoc\n⚠️➜ You don't have enough cash!\`\`\``})
 }
 if (amountToBet > max) {
    return message.reply({ content: `\`\`\`asciidoc\n⚠️➜ You can only gamble up to 150,000 cash!\`\`\``})
}
 if(!Number(amountToBet)) {
  let embed = new EmbedBuilder()
  .setDescription(`<a:warning:1004256966224388106>➜ ***Please provide an amount to bet!***`)
  .setColor("#b30000")
     return message.reply({ embeds: [embed] })
}
    let money = parseInt(args[0]);
    let win = false;

    let number = []
    for (let i = 0; i < 3; i++) { number[i] = Math.floor(Math.random() * slotItems.length); }

    if (number[0] == number[1] && number[1] == number[2])  { 
        money *= 3
        win = true;
    } else if (number[0] == number[1] || number[0] == number[2] || number[1] == number[2]) { 
        money *= 3
        win = true;
    }
    if (win) {
        const intro1 = new EmbedBuilder()
        .setColor(client.embedColor)
        .setDescription("<a:dc_loading:1043066228568231996>➜ ***You start gambling...***")
        message.reply({embeds: [intro1]}).then((msg) => {
            let time = "3s";
            setTimeout(function () {
              msg.edit({
                content: "\`\`\`asciidoc\nThis is the result!\`\`\`",
                embeds: [slotsEmbed1]
              });
            }, ms(time))
          });
        let slotsEmbed1 = new EmbedBuilder()
            .setDescription(`<a:money:1044474108739592294>➜ **${message.author.username}, just started betting:** <:ayumi_cash:1044447888413040680> __**${amountToBet.toLocaleString()}**__\n<:line:972780438118629386> **You just won:** <:ayumi_cash:1044447888413040680> __**${money.toLocaleString()}**__\n\n**[ <a:slots:1044575656966631524> | SLOTS ]**\n**----------------**\n**${slotItems[number[0]]} : ${slotItems[number[1]]} : ${slotItems[number[2]]} <**\n**----------------**\n**[ : : : WIN : : : ]**`)
            .setColor(client.embedColor)
            .setFooter({text: `Player ID: ${message.author.id}`})
            .setTimestamp()
        let profile = await currency.findOneAndUpdate({
            userID: message.author.id
            }, {
              $inc: {
              cash: amountToBet * 3,
              }
            })  
    } else {
        const intro = new EmbedBuilder()
        .setColor(client.embedColor)
        .setDescription("<a:dc_loading:1043066228568231996>➜ ***You start gambling...***")
        message.reply({embeds: [intro]}).then((msg) => {
            let time = "3s";
            setTimeout(function () {
              msg.edit({
                content: "\`\`\`asciidoc\nThis is the result!\`\`\`",
                embeds: [slotsEmbed]
              });
            }, ms(time))
          });
        let slotsEmbed = new EmbedBuilder()
            .setDescription(`<a:money:1044474108739592294>➜ **${message.author.username}, just started betting:** <:ayumi_cash:1044447888413040680> __**${amountToBet.toLocaleString()}**__\n<:line:972780438118629386> **You just lose:** <:ayumi_cash:1044447888413040680> __**${amountToBet.toLocaleString()}**__ **:C**\n\n**[ <a:slots:1044575656966631524> | SLOTS ]**\n**----------------**\n**${slotItems[number[0]]} : ${slotItems[number[1]]} : ${slotItems[number[2]]} <**\n**----------------**\n**[ : : : LOSE : : : ]**`)
            .setColor("#b30000")
            .setFooter({text: `Player ID: ${message.author.id}`})
            .setTimestamp()
        let profile = await currency.findOneAndUpdate({
            userID: message.author.id
        }, {
            $inc: {
            cash: -amountToBet,
          }
        })      
    }

}
}