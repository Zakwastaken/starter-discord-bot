const Color = `#808080`
let { EmbedBuilder } = require("discord.js")
const eco = require('../../schema/economy');
const ms = require('ms');

module.exports = {
    name: 'dice',
    category: "Economy",
    cooldown: 10,
    description: 'Roll a dice.',
    aliases: ["dc"],
    boostersOnly: false,
    // cooldownMsg: {title: "Slow Down!", description: "> You can use this command every **${timecommand}**!\n> Try again in: **${timeleft}**", color: "RED"},
    execute: async (message, args, client, prefix) => {
     
    let profile; 
    try {
        const user =
        message.mentions.users.first() ||
        client.users.cache.filter((user) => user.username).get(args[0]) ||
        client.users.cache.filter((user) => user.tag).get(args[0]) ||
        client.users.cache.filter((user) => user.id).get(args[0]) ||
        message.author;
          let profile = await eco.findOne({
            userID: message.author.id,
          })
         if(!profile) {
            if (!profile && user.id === message.author.id) return message.reply({ content: `\`\`\`asciidoc\nYou are not yet registered to the economy system, ${prefix}register to register yourself.\`\`\``})
         }
         let amountToBet = args
         let max = 150000;
         if (profile.cash < amountToBet) {
          return message.reply({ content: `\`\`\`asciidoc\n⚠️➜ You don't have enough cash!\`\`\``})
         }
         if (amountToBet > max) {
          return message.reply({ content: `\`\`\`asciidoc\n⚠️➜ You can only gamble up to 150,000 cash!\`\`\``})
         }
         if(!amountToBet){
            let embed = new EmbedBuilder()
                  .setDescription(`<a:warning:1004256966224388106>➜ ***Please provide an amount to bet!***`)
                  .setColor("#b30000")
               return message.reply({ embeds: [embed] })
          }
         if(!Number(amountToBet)) {
          let embed = new EmbedBuilder()
                  .setDescription(`<a:warning:1004256966224388106>➜ ***Please provide an valid number of cash you want to bet!***`)
                  .setColor("#b30000")
               return message.reply({ embeds: [embed] })
           }
      profile = await eco.findOne({
        userID: message.author.id,
      })
      if(!profile) {
        profile = await eco.create({
          userID: message.author.id,
          cash: 0,
          balance: 0,
        })
        profile.save()
      }
    } catch (e) {
      console.error(e)
    }

    let bot = Math.floor(Math.random() * (6 - 1) + 1)
    let player = Math.floor(Math.random() * (6 - 1) + 1)

    if(!args[0]) return message.channel.send(`\`\`\`asciidoc\n⚠️➜ Specify amount to bet!\`\`\``)

    let bet;

    if(isNaN(args[0])) {
      if(args[0] !== 'all' || args[0] !== 'max') {
        return message.channel.send(`\`\`\`asciidoc\n⚠️➜ Please specify a valid amount!\`\`\``)
      } else {
        bet = profile.cash
      }
    } else {
      bet = Number(args[0])
    }
    let sendEmbed = (winorloose) => {
        const intro = new EmbedBuilder()
        .setColor(client.embedColor)
        .setDescription("<a:dc_loading:1043066228568231996>➜ ***You start gambling...***")
        message.reply({embeds: [intro]}).then((msg) => {
            let time = "3s";
            setTimeout(function () {
              msg.edit({
                content: "\`\`\`asciidoc\nThis is the result!\`\`\`",
                embeds: [embed]
              });
            }, ms(time))
          });
      let embed = new EmbedBuilder()
      .setDescription(`_\`\`\`ascidoc\n🎲➜ You ${winorloose} at rolling the dice and ${winorloose == 'won' ? `got [ ${bet * 2} ] cash.` : winorloose == 'lost' ? `paid [ ${bet} ] cash.` : `you get your [ ${bet} ] cash back.`}\`\`\`_`)
      .addFields([{ name: `<:line2:972782869481144340> ʏᴏᴜ ʀᴏʟʟᴇᴅ :`, value: `\`\`\`fix\n${player}\`\`\``},
                  { name: `<:line:972780438118629386> ɪ ʀᴏʟʟᴇᴅ :` , value: `\`\`\`fix\n${bot}\`\`\`` }
    ])
    .setFooter({text: `Player ID: ${message.author.id}`})
    .setTimestamp()
      .setColor(`${winorloose == 'won' ? 'Green' : winorloose == 'lost' ? "Red" : Color}`)
    }
    if(bot > player) {
      sendEmbed('lost')
      await eco.findOneAndUpdate({
        userID: message.author.id
      }, {
        $inc: {
          cash: -bet,
        }
      })
    } else if(player > bot) {
      sendEmbed('won')
      let amount = Math.floor(bet * 2)
      await eco.findOneAndUpdate({
        userID: message.author.id
      }, {
        $inc: {
          cash: amount,
        }
      })
    } else if(player == bot) {
      sendEmbed(`tied`)
    }

}
      }