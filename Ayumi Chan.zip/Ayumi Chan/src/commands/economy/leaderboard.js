const Discord = require('discord.js')
const { EmbedBuilder } = require("discord.js");
const eco = require('../../schema/economy');
const ms = require('ms');

module.exports = {
    name: 'leaderboard',
    category: "Economy",
    description: 'Check whos the richest person in the server.',
    aliases: ['richest', 'lb'],
    cooldown: 10,
    boostersOnly: false,
    // cooldownMsg: {title: "Slow Down!", description: "> You can use this command every **${timecommand}**!\n> Try again in: **${timeleft}**", color: "RED"},
    execute: async (message, args, client, prefix) => {
    let profile;
    try {
        const user =
    message.mentions.users.first() ||
    client.users.cache.filter((user) => user.username).get(args[0]) ||
    client.users.cache.filter((user) => user.tag).get(args[0]) ||
    client.users.cache.filter((user) => user.id).get(args[0]) ||
    message.author;
    message.author;
      let profile = await eco.findOne({
        userID: message.author.id,
      })
     if(!profile) {
        if (!profile && user.id === message.author.id) return message.reply({ content: `\`\`\`asciidoc\nYou are not yet registered to the economy system, ${prefix}register to register yourself.\`\`\``})
     }
      profile = await eco.findOne({
        userID: message.author.id,
      })
      if(!profile) {
        profile = await eco.create({
          userID: message.author.id,
          cash: 0,
          balance: 0
        })
        profile.save()
      }
    } catch (e) {
      console.error(e)
    }

    let find = await eco.find()

    find = find.filter(value => message.guild.members.cache.get(value.userID)).sort((a, b) => {
      return b.balance - a.balance
    })

    let top;
    if(!isNaN(args[0])) {
      top = args[0]
    } else {
      if(args[0] !== 'all') {
      top = 20
      } else {
        top = find.length
      }
    }

    let mapped  = find.map((value, index) => {
      return `[#${index+1}] ${client.users.cache.get(value.userID).tag} - ${Number(value.balance).toLocaleString()} Cash.`
    })

    let test = mapped.filter(value => {
      return value.includes(message.author.tag)
    })

    let place = Number(test.join().slice(3, 4))

    let desc = mapped.slice(0, top).join("\n").replace("[#1]", `🥇`).replace("[#2]", `🥈`).replace("[#3]", `🥉`)
    const intro = new EmbedBuilder()
    .setColor(client.embedColor)
    .setDescription("<a:dc_loading:1043066228568231996>➜ ***Please wait a moment...***")
    message.reply({embeds: [intro]}).then((msg) => {
        let time = "3s";
        setTimeout(function () {
          msg.edit({
            content: "\`\`\`asciidoc\nThis is the result!\`\`\`",
            embeds: [embed]
          });
        }, ms(time))
      });
    let embed = new EmbedBuilder()
    .setAuthor({ name: `Top ${top} Richest Users In ${message.guild.name}`, iconURL: message.guild.iconURL()})
    .setDescription(`\n\n\`\`\`asciidoc\n${desc}\`\`\``)
    .setColor(client.embedColor)
    .setFooter({
        text: "© Ayumi Economy System 2022"
         })
}
          }