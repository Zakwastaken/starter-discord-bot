const economyUser = require('../../schema/economy');
const { EmbedBuilder } = require("discord.js");
const config = require('../../configg');
const ms = require('ms');

module.exports = {
	name: 'balance',
	description: 'This command allows you to check someones or your own balance for the economy system.',
	usage: '<mentionUser>',
	category: 'Economy',
	cooldown: 10,
	aliases: ['bal', 'cash'],

	execute: async (message, args, client, prefix) => {
		try {
            const user =
            message.mentions.users.first() ||
            client.users.cache.filter((user) => user.username).get(args[0]) ||
            client.users.cache.filter((user) => user.tag).get(args[0]) ||
            client.users.cache.filter((user) => user.id).get(args[0]) ||
            message.author;
            message.author;
	  const data = await economyUser.findOne({ userID: message.author.id });
	  if (!data && user.id === message.author.id) return message.reply({ content: `\`\`\`asciidoc\nYou are not yet registered to the economy system, ${prefix}register to register yourself.\`\`\``})
			const member = message.guild.members.cache.get(message.author.id);
			economyUser.findOne({ userID: member.id }, (err, user) => {
				if (err) console.log(err);
				let money = 0;
				let cash = 0;
				if (user) {
					money = user.balance ? user.balance : 0;
					cash = user.cash ? user.cash : 0;
				}
				const intro = new EmbedBuilder()
                .setColor(client.embedColor)
				.setDescription("<a:dc_loading:1043066228568231996>➜ ***Please wait a moment...***")
				message.reply({embeds: [intro]}).then((msg) => {
					let time = "3s";
					setTimeout(function () {
					  msg.edit({
						content: "\`\`\`asciidoc\nThis is the result!\`\`\`",
						embeds: [embed]
					  });
					}, ms(time))
				  });
				const embed = new EmbedBuilder()
                .setColor(client.embedColor)
                .setFooter({text: `Player ID: ${message.author.id}`})
                .setTimestamp()      
					.setAuthor({ name: "𝘜𝘴𝘦𝘳 𝘉𝘢𝘯𝘬 𝘈𝘤𝘤𝘰𝘶𝘯𝘵", iconURL: client.user.displayAvatarURL({ dynamic: true })})
					.setDescription(
						`_\`\`\`asciidoc\n${message.author.username}, this is [ ${member.user.tag} ] current money balance!\`\`\`_\n_\`\`\`asciidoc\n====================================\n› Total Cash : 💸 ${cash.toLocaleString()}\n› Total Deposit : 💸 ${money.toLocaleString()}\n› Balance : 💸 ${(cash + money).toLocaleString()}\n====================================\`\`\`_`
					);
			});
		} catch {
			return message.reply('_\`\`\`fix\n⚠️➜ You must mention a user or provide a Valid ID!\`\`\`_');
		}
			}
		}
