const { EmbedBuilder, ActionRowBuilder, ButtonStyle, ButtonBuilder } = require("discord.js");
const config = require('../../configg');

module.exports = {
    name: "rules",
    category: "Economy",
    description: "Show economy rules.",
    aliases: ["privacy"],
    cooldown: 10,
    execute: async (message, args, client, prefix) => {
        const user =
		message.mentions.users.first() ||
		client.users.cache.filter((user) => user.username).get(args[0]) ||
		client.users.cache.filter((user) => user.tag).get(args[0]) ||
		client.users.cache.filter((user) => user.id).get(args[0]) ||
		message.author;
		const data = await economyUser.findOne({ userID: message.author.id });
		if (!data && user.id === message.author.id) return message.reply({ content: `\`\`\`asciidoc\nYou are not yet registered to the economy system, ${prefix}register to register yourself.\`\`\``})
		if (!data) return message.reply({ content: `\`\`\`asciidoc\nThis user is not registered to the economy system, ${prefix}register\`\`\`` })
        const urlbutt2 = new ButtonBuilder().setLabel("Support Server.").setStyle(ButtonStyle.Link).setEmoji("<a:correct:1004239653072801922>").setURL("https://bit.ly/3IiX5wS")
        const row3 = new ActionRowBuilder().addComponents(urlbutt2)
    let embed = new EmbedBuilder()
    .setAuthor({ name: "Ayumi Chan General Rules.", iconURL: client.user.displayAvatarURL({dynamic: true, size: 1024})})
    .setDescription(`\`\`\`asciidoc\n> Using macros, autotypers, or scripts of any kind is strictly prohibited as it creates unfair play.\n> Trading of any type of item is strictly prohibited, including for Ayumi Cash itself without further notification from the Bot Owner.\n> Using multiple accounts to get more Ayumi Cash is perfectly allowed because it doesn't violate the main rules.\n> If there is a problem or bug in this bot, you can join Ayumi Chan's bot server support to report it.\`\`\`\n***"If you have read these rules, it means that you agree and are ready to follow these rules."***`)
    .setFooter({text: `PT Wibu Cahaya Asia.`})
    .setColor(client.embedColor)
    return message.reply({embeds: [embed], components: [row3]})
}}