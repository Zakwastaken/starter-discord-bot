const { EmbedBuilder, ActionRowBuilder, ButtonStyle, ButtonBuilder, Interaction } = require("discord.js");
const econoymSchema = require("../../schema/economy");
const config = require('../../configg');
const moment = require('moment');

module.exports = {
  name: "unregister",
  category: 'Owner Only',
  cooldown: 10,
  description: "Delete all your data from the economic system.",
  execute: async (message, args, client, prefix) => {
    const verify = "<a:correct:1004239653072801922>";
    const cancel = "<a:false:1004240014126887014>";

    const econ = await econoymSchema.findOne({ userID: message.author.id })
    if (!econ) return message.reply({ content: `\`\`\`asciidoc\nYou are not registered to the economic system. ${prefix}register to register yourself!\`\`\`` });
    const components = (state) => [
    new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("verify")
          .setEmoji(verify)
          .setStyle(ButtonStyle.Success)
          .setLabel("Yes")
          .setDisabled(state),
      new ButtonBuilder()
          .setCustomId("deny")
          .setEmoji(cancel)
          .setStyle(ButtonStyle.Danger)
          .setLabel("No")
          .setDisabled(state)
          )
        ]
    const initialEmbed = new EmbedBuilder()
    .setColor("#b30000")
    .setAuthor({ name: "Unregister?", iconURL: client.user.displayAvatarURL()})
      .setDescription(`<a:warning:1004256966224388106>➜ ***Are you sure you want to Unregister yourself from the economy system?***\n<:line2:972782869481144340> **Click ${verify} to unregister.**\n<:line:972780438118629386> **Click ${cancel} to cancel the unregistration.**`)
    const initialMessage = await message.reply({
      embeds: [initialEmbed],
      components: components(false)
    })
    const collector = initialMessage.createMessageComponentCollector({
      filter: (b) => {
      if(b.user.id === message.author.id) return true;
       else {
     b.reply({ ephemeral: true, content: `\`\`\`ini\nOnly [ ${message.author.tag} ] can use this button, run the command again to use the help menu.\`\`\``}); return false;
           };
      },
      time : 60000,
      max: 1,
    });
    collector.on("collect", async b => {
      if (b.customId === "verify") {
        if(!b.deferred) await b.deferUpdate()
        const editEmbed = new EmbedBuilder()
          .setTitle("UNREGISTERED!")
          .setDescription(`<a:correct:1004239653072801922>➜ ***Your data from the economy system has been deleted!***`)
          .setColor(client.embedColor)
          initialMessage.edit({ embeds: [editEmbed], components: components(true) });
        econ.delete()
      } else if (b.customId === "deny") {
        await b.deferUpdate();
        const editEmbed = new EmbedBuilder()
          .setTitle("CANCELLED!")
          .setDescription(`<a:false:1004240014126887014>➜ ***You cancelled your Unregistration from the economic system!***`)
          .setColor("#b30000")
      initialMessage.edit({ embeds: [editEmbed], components: components(true) });
      
      collector.on("end", (reason) => {
        if(reason == "time"){
         initialMessage.edit({content: "\`\`\`asciidoc\nCommands Timed Out!\`\`\`", components: [disabledRow]})
            }else {
       
       initialMessage.edit({ embeds: [editEmbed], components: components(true) });
            }
         });
      }
    })
  },
};