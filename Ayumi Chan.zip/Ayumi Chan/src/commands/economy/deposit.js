const { EmbedBuilder } = require("discord.js")
const math = require('mathjs');
let eco = require("../../schema/economy");
const number = require("../../utils/number")

module.exports = {
    name: 'deposit',
    category: "Economy",
    description: 'Deposit some money to your bank!',
    usage: '<amount>',
    aliases: ['dep'],
	cooldown: 10,
    boostersOnly: false,
	execute: async (message, args, client, prefix) => {
     
    let profile;
	const user =
    message.mentions.users.first() ||
    client.users.cache.filter((user) => user.username).get(args[0]) ||
    client.users.cache.filter((user) => user.tag).get(args[0]) ||
    client.users.cache.filter((user) => user.id).get(args[0]) ||
    message.author;
    try {
      profile = await eco.findOne({
        userID: message.author.id
      })
	  if(!profile) {
        if (!profile && user.id === message.author.id) return message.reply({ content: `\`\`\`asciidoc\nYou are not yet registered to the economy system, ${prefix}register to register yourself.\`\`\``})
     }
	 let amountToBet = args
     if (profile.cash < amountToBet) {
     return message.reply({ content: `\`\`\`asciidoc\n⚠️➜ You don't have enough cash!\`\`\``})
}
     if (profile.cash === 0) {
  return message.reply({ content: `\`\`\`asciidoc\n⚠️➜ You don't have enough cash!\`\`\``})
}
     if (profile.cash < 0) {
  return message.reply({ content: `\`\`\`asciidoc\n⚠️➜ You don't have enough cash!\`\`\``})
}
      if(!profile) {
        if(message.author.bot) return;
        profile = await eco.create({
          userID: message.author.id,
          cash: 0,
          balance: 0,
        })
        profile.save()
      }
    } catch (e) {
      console.error(e)
    }

    if(profile) {

    if(!args[0]) return message.channel.send(`\`\`\`asciidoc\n⚠️➜ Specify the amount you want to deposit!\`\`\``)

    let amount;

    if(isNaN(args[0])) {
      if(args[0] == 'max' || args[0] == 'all') {
        if(profile.cash > profile.balance) {
          amount = profile.cash - profile.balance
        } else {
          amount = profile.cash
        }
    } else {
      return message.channel.send(`\`\`\`⚠️➜ You must deposit a [ number or max ] to deposited all!\`\`\``)
    }
    } else {
      if(args[0] > profile.cash) {
        amount = profile.cash
        } else {
          if(args[0] <= profile.cash && !isNaN(args[0])) {
          amount = args[0]
        }
      }
    }

  try {
    await eco.findOneAndUpdate(
        {
          userID: message.author.id,
        },
        {
          $inc: {
            cash: -amount,
            balance: amount,
          },
        }
      );
    } catch (err) {
      console.log(err);
    }

    let updatedBank = math.floor(profile.balance + Number(amount))
    const embed = new EmbedBuilder()
    .setColor(client.embedColor)
    .setFooter({text: `Player ID: ${message.author.id}`})
    .setTimestamp()
	 .setDescription(`<a:correct:1004239653072801922>➜ **${message.author.username} has successfully deposited:** <:ayumi_cash:1044447888413040680>  __**${Number(amount).toLocaleString()}**__\n<:line:972780438118629386> **Total Balance:** <:ayumi_cash:1044447888413040680> __**${Number(updatedBank).toLocaleString()}**__`)
   return message.reply({ embeds: [embed] })
    } else {
      return message.channel.send(`\`\`\`asciidoc\nError! Try Again!\`\`\``)
    }

    }}