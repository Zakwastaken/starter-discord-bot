let economyUser = require("../../schema/economy");
const { EmbedBuilder } = require('discord.js');
const OWNERID = "760723665372971008";

const addMoney = async (userID, cash = 0) => {
	await economyUser.updateOne({ userID }, { $set: { userID }, $inc: { cash } }, { upsert: true });
};

module.exports = {
	name: 'addcash',
	description: 'Add money to a user, a bot administrator only for commands.',
	usage: '<mentionUser> <amount>',
	cooldown: 10,
	example: '@Komi#0001 10000',
	aliases: ['add-balance', 'addbalance', 'add'],
	category: 'Owner Only',
	ownerOnly: true,

	execute: async (message, args, client, prefix) => {
        if (message.author.id != OWNERID) {
            let warning = new EmbedBuilder()
            .setColor("#b30000")
            .setDescription("\`\`\`fix\nOnly Zakuro can use this commands!\`\`\`")
            return message.reply({ embeds: [warning] });
          }
		const member = message.mentions.users.first() || client.users.cache.get(args[0]);
		if (!member) return message.reply('\`\`\`fix\nYou must mention someone!\`\`\`');

		const bal = Number(args[1]) || 0;
		await addMoney(member.id, bal);
        const embed = new EmbedBuilder()
        .setColor(client.embedColor)
        .setFooter({text: `Player ID: ${message.author.id}`})
        .setTimestamp()
        .setDescription(`\`\`\`fix\n${message.author.username} has successfully sended [ 💸 ${bal.toLocaleString()} ] to { ${member.username} } balance!\`\`\``)
		return message.reply({ embeds: [embed] });
	}
};