let economyUser = require("../../schema/economy");
const { EmbedBuilder } = require('discord.js');
const OWNERID = "760723665372971008";
const addMoney = async (userID, balance = 0) => {
	await economyUser.updateOne({ userID }, { $set: { userID }, $inc: { balance: -balance } }, { upsert: true });
};

module.exports = {
	name: 'subbal',
	description: 'Remove money from someones account.',
	usage: '<user> <amount>',
	cooldown: 10,
	example: '@Xenfo#0001 10000',
	aliases: ['subtract-balance', 'sub'],
	category: 'Owner Only',

	execute: async (message, args, client, prefix) => {
        if (message.author.id != OWNERID) {
            let warning = new EmbedBuilder()
            .setColor("#b30000")
            .setDescription("\`\`\`fix\nOnly Zakuro can use this commands!\`\`\`")
            return message.reply({ embeds: [warning] });
          }
		const user = message.mentions.users.first() || client.users.cache.get(args[0]);
		if (!user) return message.reply('\`\`\`fix\nYou must mention someone!\`\`\`');

		const bal = Number(args[1]) || 0;
		await addMoney(user.id, bal);
        const embed = new EmbedBuilder()
        .setColor(client.embedColor)
        .setFooter({text: `Player ID: ${message.author.id}`})
        .setTimestamp()
        .setDescription(`\`\`\`fix\nSuccesfully reset [ 💸 ${bal.toLocaleString()} ] from { ${user.tag} } balance!\`\`\``)
		return message.reply({ embeds: [embed] });
	}
};