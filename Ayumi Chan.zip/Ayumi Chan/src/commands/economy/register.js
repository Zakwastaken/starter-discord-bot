const econoymSchema = require("../../schema/economy");
const { EmbedBuilder } = require("discord.js");
const moment = require('moment');


module.exports = {
  name: "register",
  category: 'Economy',
  cooldown: 10,
  description: "Register yourself in the economy system.",
  execute: async (message, args, client, prefix) => {
    econoymSchema.findOne({ userID: message.author.id }, async (err, data) => {
      if (data) return message.reply({ content: `\`\`\`asciidoc\nYou are already registered to the economic system!\`\`\`` })
      else {
        new econoymSchema({
          userID: message.author.id,
          createdAt: (Date.now() * 1000) / 1000,
          cash: 5000
        }).save()
        const registered = new EmbedBuilder()
        .setAuthor({ name: "REGISTERED!", iconURL: client.user.displayAvatarURL()})
          .setDescription(`<a:correct:1004239653072801922>➜ ***Hello ${message.author.username}, You have been registered to the Economy System!***\n<:line:972780438118629386> **Time:** \`${moment((Date.now() * 1000) / 1000).fromNow()}\``)
          .setColor(client.embedColor)
          .setFooter({text: `Player ID: ${message.author.id}`})
          .setTimestamp()
         message.reply({ embeds: [registered] })
      }
    })
  }
}