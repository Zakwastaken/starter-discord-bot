let economyUser = require("../../schema/economy");
const { EmbedBuilder } = require('discord.js');
const ms = require('ms');

const COOLDOWN = 1 * 24 * 60 * 60 * 1000;

const addMoney = async (userID, cash = 0) => {
	await economyUser.updateOne(
		{ userID },
		{ $set: { userID, 'cooldowns.TRANSFER': Date.now() + COOLDOWN }, $inc: { cash } },
		{ upsert: true }
	);
};

module.exports = {
	name: 'transfer',
	description: 'Transfer money to another discord user.',
	usage: '<user> <amount>',
	example: '@Xenfo#0001 400',
	category: 'Economy',
	aliases: ['give'],
	cooldown: 10,
	execute: async (message, args, client, prefix) => {
		const profile =
		message.mentions.users.first() ||
		client.users.cache.filter((user) => user.username).get(args[0]) ||
		client.users.cache.filter((user) => user.tag).get(args[0]) ||
		client.users.cache.filter((user) => user.id).get(args[0]) ||
		message.author;
		const member = await economyUser.findOne({ userID: message.author.id });
		if (!member && profile.id === message.author.id) return message.reply({ content: `\`\`\`asciidoc\nYou are not yet registered to the economy system, ${prefix}register to register yourself.\`\`\``})
        const user = message.mentions.users.first() || client.users.cache.get(args[0]);
        if (!user) {
			const embed = new EmbedBuilder()
            .setColor("#b30000")
            .setDescription(`<a:warning:1004256966224388106>➜ ***You must mention someone!***`)
			return message.reply({ embeds: [embed] }).then((msg) => {
				let time = "5s";
				setTimeout(function () {
				  msg.delete();
				}, ms(time));
			  });
		}
		if (user.id === message.author.id) return message.reply({ content: `\`\`\`fix\nHey stupid, Are you still in your right mind sending money to yourself? -_-\`\`\`` })
		const deduct = Number(args[1]) || 0;
		if (member.cash < deduct) {
			return message.reply({ content: `\`\`\`\n⚠️➜ You don't have enough cash!\`\`\``})
		   }
		await addMoney(message.author.id, -deduct);
		await addMoney(user.id, deduct);
		const embed1 = new EmbedBuilder()
        .setColor(client.embedColor)
        .setFooter({text: `Player ID: ${message.author.id}`})
        .setTimestamp()
		.setDescription(`<a:correct:1004239653072801922>➜ **${message.author.username} has successfully sended** <:ayumi_cash:1044447888413040680> __**${deduct.toLocaleString()}**__ **to  ${user.tag} balance!**`)
		return message.reply({ embeds: [embed1] });
	}
};