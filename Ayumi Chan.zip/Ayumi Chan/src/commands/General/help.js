const { EmbedBuilder, ActionRowBuilder, ButtonStyle, ButtonBuilder } = require("discord.js");

module.exports = {
    name: "help",
    category: "Information",
    aliases: [ "h" ],
    description: "Help with all commands, or one specific command.",
    args: false,
    usage: "",
    userPerms: [],
    owner: false,
 execute: async (message, args, client, prefix) => {

  const embed = new EmbedBuilder()
  .setAuthor({ name: `${client.user.username} Home Page.`, iconURL: client.user.displayAvatarURL()})
    .setDescription(`\nHello *<@${message.author.id}>* 👋\nWelcome to **${client.user.username}** Homepage\nCurrently my prefix on **${message.guild.name}** is \`${prefix}\`\nUse \`${prefix}\` as the default prefix.\nThank you for using me.\n\n• Category List\n[<:home:972764374131408916>] • **Home**\n[<:general:1028630609515532408>] • **General**\n[<:musiccc:1028630552615596122>] • **Song**\n[<:gears:1037191628806430812>] • **Settings**\n[<:economy:1044581691047546930>] • **Economy**\n\n\nPlease **click** the *button* below to **see** the **help-pages** of each category provided above.\n\n`)
    .setThumbnail(client.user.displayAvatarURL())
    .setColor(client.embedColor)
    .setTimestamp()
    .setFooter({text: `© PT Wibu Cahaya Asia Development 2022`})
    .setTimestamp()
                
    let but1 = new ButtonBuilder().setCustomId("home").setEmoji('<:home:972764374131408916>').setStyle(ButtonStyle.Success)
  
    let but2 = new ButtonBuilder().setCustomId("music").setEmoji("<:musiccc:1028630552615596122>").setStyle(ButtonStyle.Primary)
  
    let but3 = new ButtonBuilder().setCustomId("info").setEmoji("<:general:1028630609515532408>").setStyle(ButtonStyle.Primary);

    let but4 = new ButtonBuilder().setCustomId("setting").setEmoji("<:gears:1037191628806430812>").setStyle(ButtonStyle.Primary);

    let but5 = new ButtonBuilder().setCustomId("economy").setEmoji("<:economy:1044581691047546930").setStyle(ButtonStyle.Primary);
    
     let _commands;
     let editEmbed = new EmbedBuilder();
     
     const m = await message.reply({ embeds: [embed], components: [new ActionRowBuilder().addComponents(but1, but2, but3, but4, but5)] });

    const collector = m.createMessageComponentCollector({
      filter: (b) => {
      if(b.user.id === message.author.id) return true;
       else {
     b.reply({ ephemeral: true, content: `\`\`\`ini\nOnly [ ${message.author.tag} ] can use this button, run the command again to use the help menu.\`\`\``}); return false;
           };
      },
      time : 60000,
      idle: 60000/2
    });
    collector.on("end", async () => {
		 if(!m) return;
        await m.edit({ components: [new ActionRowBuilder().addComponents(but1.setDisabled(true), but2.setDisabled(true), but3.setDisabled(true), but4.setDisabled(true), but5.setDisabled(true))] }).catch(() => {});
    });
    collector.on('collect', async (b) => {
       if(!b.deferred) await b.deferUpdate()
        if(b.customId === "home") {
           if(!m) return;
           return await m.edit({ embeds: [embed], components: [new ActionRowBuilder().addComponents(but1, but2, but3, but4, but5)] })
        }
        if(b.customId === "music") {
         _commands = client.commands.filter((x) => x.category && x.category === "Music").map((x) => `${x.name}`);
             editEmbed.setColor(client.embedColor).setThumbnail(client.user.displayAvatarURL()).setDescription(`\nCurrently my prefix on **${message.guild.name}** is \`${prefix}\`\nUse \`${prefix}\` as the default prefix.\nThank you for using me.\n\n_\`\`\`fix\n${_commands.join(", ")}\`\`\`_`).setAuthor({ name: "Song Category.", iconURL: client.user.displayAvatarURL()}).setFooter({text: `Page 1/4 ~ Total ${_commands.length} Commands.`});
           if(!m) return;
           return await m.edit({ embeds: [editEmbed], components: [new ActionRowBuilder().addComponents(but1, but2, but3, but4, but5)] })
        }
         if(b.customId == "info") {
         _commands = client.commands.filter((x) => x.category && x.category === "Information").map((x) => `${x.name}`);
             editEmbed.setColor(client.embedColor).setThumbnail(client.user.displayAvatarURL()).setDescription(`\nCurrently my prefix on **${message.guild.name}** is \`${prefix}\`\nUse \`${prefix}\` as the default prefix.\nThank you for using me.\n\n_\`\`\`fix\n${_commands.join(", ")}\`\`\`_`).setAuthor({ name: "General Category.", iconURL: client.user.displayAvatarURL()}).setFooter({text: `Page 2/4 ~ Total ${_commands.length} Commands.`})
          return await m.edit({ embeds: [editEmbed], components: [new ActionRowBuilder().addComponents(but1, but2, but3, but4, but5)] })
         }
         if(b.customId == "setting") {
          _commands = client.commands.filter((x) => x.category && x.category === "Setup").map((x) => `${x.name}`);
              editEmbed.setColor(client.embedColor).setThumbnail(client.user.displayAvatarURL()).setDescription(`\nCurrently my prefix on **${message.guild.name}** is \`${prefix}\`\nUse \`${prefix}\` as the default prefix.\nThank you for using me.\n\n_\`\`\`fix\n${_commands.join(", ")}\`\`\`_`).setAuthor({ name: "Settings Category.", iconURL: client.user.displayAvatarURL()}).setFooter({text: `Page 3/4 ~ Total ${_commands.length} Commands.`})
           return await m.edit({ embeds: [editEmbed], components: [new ActionRowBuilder().addComponents(but1, but2, but3, but4, but5)] })
          }
          if(b.customId == "economy") {
            _commands = client.commands.filter((x) => x.category && x.category === "Economy").map((x) => `${x.name}`);
                editEmbed.setColor(client.embedColor).setThumbnail(client.user.displayAvatarURL()).setDescription(`\nCurrently my prefix on **${message.guild.name}** is \`${prefix}\`\nUse \`${prefix}\` as the default prefix.\nThank you for using me.\n\n_\`\`\`fix\n${_commands.join(", ")}\`\`\`_`).setAuthor({ name: "Economy Category.", iconURL: client.user.displayAvatarURL()}).setFooter({text: `Page 4/4 ~ Total ${_commands.length} Commands.`})
             return await m.edit({ embeds: [editEmbed], components: [new ActionRowBuilder().addComponents(but1, but2, but3, but4, but5)] })
            }
     });
   }
 }