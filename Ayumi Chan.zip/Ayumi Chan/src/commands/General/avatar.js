const discord = module.require("discord.js");

module.exports = {
  name: "avatar",
  aliases: ["av"],
  category: "Information",
  usage: "avatar/avatar @user",
  description: "Gives avatar for message author or mentioned user.",
  execute: async (message, args, client, prefix) => {
    let user = message.mentions.users.first() || message.author;
    let embed = new discord.EmbedBuilder()
    .setColor(client.embedColor)
    .setAuthor({ name: `${user.username}'s Avatar.`, iconURL: client.user.displayAvatarURL()})
      .setDescription(
        `**[AVATAR LINK](${user.displayAvatarURL({
          size: 2048,
          dynamic: true,
          format: "png",
        })})**`
      )
      .setImage(user.avatarURL({ size: 2048, dynamic: true, format: "png" }));

    message.reply({ embeds: [embed] });
  },
};