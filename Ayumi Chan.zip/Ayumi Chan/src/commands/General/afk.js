const Discord = require("discord.js");
const { Color, Prefix } = require("../../configg");
const { EmbedBuilder } = require("discord.js")
const schema = require('../../schema/afk');
const { set } = require("lodash");

module.exports = {
	name: "afk",
	aliases: [],
	category: "Information",
    description: 'Away from keyboard.',
	example: `${Prefix}afk <reason>`,
	description: "",
    execute: async (message, args, client, prefix) => {
		let data;
    try {
        data = await schema.findOne({
            userId: message.author.id,
            guildId: message.guild.id,
        })
        if(!data) {
            data = await schema.create({
                userId: message.author.id,
                guildId: message.guild.id,
            })
        }
    } catch(e) {
    }
    data.AFK = true
    data.AFK_Reason = args.join(" ")
    await data.save()
    const embed = new EmbedBuilder()
    .setColor(client.embedColor)
    .setDescription(`<a:correct:1004239653072801922>➜ ***Successfully setted your AFK status!***\n<:line:972780438118629386> **Status:** ${data.AFK_Reason || "no reason." }`)
		message.reply({ embeds: [embed] });
	}
}