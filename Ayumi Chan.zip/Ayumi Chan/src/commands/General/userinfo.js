const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('discord.js');
const moment = require('moment');

module.exports = {
    name: 'userinfo',
    category: 'Information',
    aliases: ['whois'],
    utilisation: '{prefix}userinfo',
    description: 'Show user userinfo.',

    execute: async (message, args, client, prefix) => {
        var user;
        if (args[0] && !message.mentions.users.first()) {
            user = await client.users.fetch(args[0])
            .catch(error => client.error(error, message.channel));
            if (!user) return;
        } else if (message.mentions.users.first()) {
            user = await message.mentions.users.first();
            if (!user) return;
        } else {
            user = message.author;
        }

        var member = message.guild.members.cache.get(user.id);
        
        var createdAt = moment(user.createdTimestamp).format('LLLL');
        var joinAt = moment(member.joinedAt).format('LLLL');

        const user_embed = new EmbedBuilder()
        .setAuthor({ name: "User Information.", iconURL: client.user.displayAvatarURL()})
            .setThumbnail(user.displayAvatarURL({ dynamic: true }) || null)
            .setColor(client.embedColor)
            .addFields([{ name: '<:line2:972782869481144340> Username:', value: `\`\`\`asciidoc\n${user.tag}\`\`\``},
            { name: '<:line2:972782869481144340> User ID:', value: `\`\`\`asciidoc\n${user.id}\`\`\``},
            { name: `<:line2:972782869481144340> Roles: [${member.roles.cache.size - 1}]`, value: `\`\`\`asciidoc\n${member.roles.cache.map(r => r.name).join(', ').replace('@everyone',' ')}\`\`\``},
            { name: '<:line2:972782869481144340> Nickname:', value: `\`\`\`asciidoc\n${member.displayName}\`\`\``},
            { name: '<:line2:972782869481144340> Bot:', value: `\`\`\`asciidoc\n${user.bot ? '✔️' : '❌'}\`\`\``},
            { name: '<:line2:972782869481144340> Creation Date:', value: `\`\`\`asciidoc\n${createdAt}\`\`\``},
            { name: '<:line:972780438118629386> Joined Server:', value: `\`\`\`asciidoc\n${joinAt}\`\`\``},
        ])
        return message.reply({ embeds: [user_embed] })
    },
};