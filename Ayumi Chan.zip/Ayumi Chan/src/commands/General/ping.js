const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "ping",
  category: "Information",
  description: "Displays the bot's ping.",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  execute: async (message, args, client, prefix) => {

    await message.reply({ content: "\`\`\`asciidoc\nPinging...\`\`\`" }).then(async (msg) => {
      const ping = msg.createdAt - message.createdAt;
      const api_ping = client.ws.ping;

      const PingEmbed = new EmbedBuilder()
        .setAuthor({ name: "Bot Latency.", iconURL: client.user.displayAvatarURL() })
        .setColor(client.embedColor)
        .addFields([
          { name: "Bot Latency", value: `\`\`\`ini\n[ ${ping}ms ]\n\`\`\``, inline: true },
          { name: "API Latency", value: `\`\`\`ini\n[ ${api_ping}ms ]\n\`\`\``, inline: true }
        ])
      await msg.edit({
        content: "\`\`\`ini\n🏓➜ Pinging Bot's.\`\`\`",
        embeds: [PingEmbed]
      })
    })
  }
}