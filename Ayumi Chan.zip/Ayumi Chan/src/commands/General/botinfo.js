const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('discord.js');
const os = require('os');
const cpuStat = require("cpu-stat");
const package = require('../../../package.json');
const ms = require("ms");
const { stripIndent } = require('common-tags');
const { uptime } = require("process");
const { raw } = require('express');
module.exports = {
	name: 'botinfo',
    category: "Information",
	description: "Get the bot's information.",
	cooldown: 3000,
	userperm: ["SEND_MESSAGES"],
	botperm: ["SEND_MESSAGES"],
    execute: async (message, args, client, prefix) => {
        const emojiJoin = message.client.emoji.join;
        const embed = new EmbedBuilder()
        .setAuthor({ name: "Bot Status.", iconURL: client.user.displayAvatarURL()})
        .setColor(client.embedColor)
            .addFields([{ name: `<:line2:972782869481144340> ***Bot Creation Date***`, value: `\`\`\`${client.user.createdAt.toLocaleString()}\`\`\``},
            { name: `<:line2:972782869481144340> ***Counters***`, value: `\`\`\`asciidoc\n・Commands  :: ${client.commands.size}\n・Guilds    :: ${Math.ceil(client.guilds.cache.size)}\n・Users     :: ${client.guilds.cache.reduce((a, g) => a + (g.memberCount || 0) - 1, 0).toLocaleString()}\n・Channels  :: ${client.channels.cache.size.toLocaleString()}\`\`\``},
            { name: `<:line2:972782869481144340> ***Versions***`, value: `\`\`\`asciidoc\n・Bot        :: ${package.version}\n・Discord.js :: ${package.dependencies["discord.js"]}\n・Node.js    :: ${process.version}\`\`\``},
            { name: `<:line:972780438118629386> ***System***`, value: `\`\`\`asciidoc\n・CPU       :: ${os.cpus().map(i => `${i.model.replace(/cpu|apu|\(tm\)|\(r\)|core|with|radeon|hd|graphics/gi, "")}`)[0]}\n・RAM Usage :: ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB / ${Math.round(os.totalmem()/1024/1024).toLocaleString()} MB\n・OS        :: ${os.platform()} ${os.release} ${os.arch()}\n・Uptime    :: ${ms(os.uptime()*1000)}\`\`\``},
        ])
            .setTimestamp()
            .setFooter({
                text: "© PT Wibu Cahaya Asia 2022"
                })
            message.reply({ embeds: [embed]})
    }}
