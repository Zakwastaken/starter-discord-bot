const { EmbedBuilder } = require('discord.js');
const profileModel = require('../../schema/economy')

module.exports = {
    name: 'inventory',
    aliases: ['inv'],
    category: 'economy',
    utilisation: '{prefix}inventory',
    description: 'Allows you to see your inventory',

	execute: async (message, args, client, prefix) => {
        const user =
        message.mentions.users.first() ||
        client.users.cache.filter((user) => user.username).get(args[0]) ||
        client.users.cache.filter((user) => user.tag).get(args[0]) ||
        client.users.cache.filter((user) => user.id).get(args[0]) ||
        message.author;
          let profile = await profileModel.findOne({
            userID: message.author.id,
          })
         if(!profile) {
            if (!profile && user.id === message.author.id) return message.reply({ content: `\`\`\`asciidoc\nYou are not yet registered to the economy system, ${prefix}register to register yourself.\`\`\``})
         }  
            let number = 5 * parseInt(args[0]);
            let page;
            if (profile.items.length <= 5) page = 1;
            else if (profile.items.length <= 10) page = 2;
            else if (profile.items.length <= 15) page = 3;
            else if (profile.items.length <= 20) page = 4;
            if (!args[0]) {
                number = 5;
            }
            let item = profile.items.slice(number - 5, number);
            if (item.length < 1) {
                return message.reply('You have no items.');
            }
            const items = item.map(x => `${x.description}\n  \`id: ${x.name} \` x ${x.amount.toLocaleString()}`);
            const embed = new EmbedBuilder()
                .setThumbnail(message.author.displayAvatarURL({ format: 'png', size: 256, dynamic: true }))
                .setAuthor({name: `${message.author.username}'s Inventory`,iconURL: client.user.displayAvatarURL()})
                .setDescription(`${items.join('\n\n')}`)
                .setFooter({ text: `Page ${args[0] || 1} of ${page}. to switch pages, do ${prefix}inventory (page number).`})
                .setColor(client.embedColor)
            message.reply({ embeds: [embed] })
        }
    }
