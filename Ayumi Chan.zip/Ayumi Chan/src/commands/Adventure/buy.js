const { EmbedBuilder } = require('discord.js');
const itemss = require('../../utils/items');
const i = 'ℹ️'
const x = '❌'
const tick = '✔️'

const profileModel = require('../../schema/economy')
module.exports = {
    name: 'buy',
    aliases: [],
    category: 'economy',
    utilisation: '{prefix}buy (item ID)',
    description: 'Buy something from the shop. find the ID in the shop',
	execute: async (message, args, client, prefix) => {
            const user =
            message.mentions.users.first() ||
            client.users.cache.filter((user) => user.username).get(args[0]) ||
            client.users.cache.filter((user) => user.tag).get(args[0]) ||
            client.users.cache.filter((user) => user.id).get(args[0]) ||
            message.author;
              let profile = await profileModel.findOne({
                userID: message.author.id,
              })
             if(!profile) {
                if (!profile && user.id === message.author.id) return message.reply({ content: `\`\`\`asciidoc\nYou are not yet registered to the economy system, ${prefix}register to register yourself.\`\`\``})
             }
             const member = message.member;
            if (!args.join(' ')) {
                let buynothingerrorembed = new EmbedBuilder()
                    .setColor("Red")
                    .setDescription(`${x} **${member.user.username}** : You can't buy nothing, please enter the correct item \`id\`.`);

                return message.reply({ embeds: [buynothingerrorembed] }).catch();
                //return message.channel.send("you can't buy nothing, please enter the correct item id");
            }
            if (!args[1]) args[1] = '';
            const item = itemss.find(x => x.name.toLowerCase() === args.join(' ').toString().toLowerCase() || x.name.toLowerCase() === args[0].toString().toLowerCase() || x.name.toLowerCase() === `${args[0].toString().toLowerCase()} ${args[1].toString().toLowerCase()}`);
            if (!item) {
                let wrongiderrorembed = new EmbedBuilder()
                    .setColor("Red")
                    .setDescription(`${x} **${member.user.username}** : You can't buy an item that doesn't exist please use the correct item \`id\`.`);

                return message.reply({ embeds: [wrongiderrorembed] }).catch();
                //return message.channel.send("You can't buy an item that doesn't exist please use the correct item id");
            }
            if (item.canBuy == false) {
                let cantbuyerrorembed = new EmbedBuilder()
                    .setColor("Red")
                    .setDescription(`${x} **${member.user.username}** : You can't buy this item.`);

                return message.reply({ embeds: [cantbuyerrorembed] }).catch();
                //return message.channel.send(":thinking: You can't buy this item");
            }
            let buyAmount = args.join(' ').toString().match(/([1-9][0-9]*)/)
            if (!buyAmount) buyAmount = 1;
            else buyAmount = buyAmount[0]
            if (item.price > profile.cash || (buyAmount * item.price) > profile.cash) {
                let nomoneyerrorembed = new EmbedBuilder()
                    .setColor("Red")
                    .setDescription(`${x} **${member.user.username}** : You dont have the funds to buy this item.`);

                return message.reply({ embeds: [nomoneyerrorembed] }).catch();
                //return message.channel.send("You dont have the funds to buy this item.");
            }
            let founditem = profile.items.find(x => x.name.toLowerCase() === item.name.toLowerCase());
            let array = [];
            array = profile.items.filter(x => x.name !== item.name);
            if (founditem) {
                array.push({
                    name: item.name,
                    amount: (parseInt(founditem.amount) + parseInt(buyAmount)),
                    description: item.description
                });
                profile.items = array;
                await profile.save();
            }
            else {
                profile.items.push({
                    name: item.name,
                    amount: buyAmount,
                    description: item.description
                });
                await profile.save();
            }
            const response = await profileModel.findOneAndUpdate({
                        userID: message.author.id,
                    }, {
                        $inc: {
                            cash: -item.price,
                        }
                    })
            let itempayedembed = new EmbedBuilder()
            .setColor(client.embedColor)
                .setDescription(`${tick} **${member.user.username}** : You bought **${parseInt(buyAmount).toLocaleString()}** \`${item.name}\`.`);

            message.reply({ embeds: [itempayedembed] }).catch();
            //message.channel.send(`You bought **${parseInt(buyAmount).toLocaleString()}** \`${item.name}\``);
        }
    }
