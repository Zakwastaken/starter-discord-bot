const rifle = '🔫'
const axe = '🪓'
const pick = '⛏️'
const rc = '🌈'
const ht = '🏆'

const { EmbedBuilder } = require('discord.js');
const profileModel = require('../../schema/economy')
module.exports = {
    name: 'shop',
    aliases: [],
    category: 'economy',
    utilisation: '{prefix}shop',
    description: 'Allows you to see whats available in the shop',
	execute: async (message, args, client, prefix) => {
        const member = message.author;
        const embed = new EmbedBuilder()
        .setAuthor({ name: "Adventure Shop.", iconURL: client.user.displayAvatarURL()})
            .setColor(client.embedColor)
            .setThumbnail(member.displayAvatarURL({ format: 'png', size: 256, dynamic: true }))
            .setDescription(`🍪 **Cookie - __50__** __cash__\n\`id: cookie\`\nUse to make you fatter\n${rifle} **Rifle - __22__,__500__** __cash__\n\`id: rifle\`\nUse this to go hunting\n${axe} **Axe - __20__,__000__** __cash__\n\`id: axe\`\nUse this to cut trees down!\n🎣 **Fishing Rod - __15__,__000__** __cash__\n\`id: fishingrod\`\nUse this to go fishing!\n${pick} **Pickaxe - __30__,__000__** __cash__\n\`id: pickaxe\`\nUse this to mine gems!\n**Rainbow Coin - __100__,__000__,__000__** __cash__\n\`id: rainbowcoin\`\n **Gold Coin - __50__,__000__,__000__** __cash__\n\`id: goldcoin\`\n **Silver Coin - __15__,__000__,__000__** __cash__\n\`id: silvercoin\`\n ** Bronze Coin - __5__,__000__,__000__** __cash__\n\`id: bronzecoin\`\n${ht} **Trophy - __100__,__000__,__000__** __cash__\n\`id: trophy\``)
        message.reply({ embeds: [embed] })
    }
}