const { EmbedBuilder } = require("discord.js");
const autoResponse = require("../../schema/autoresponse");
const Guild = require("../../schema/guild");
module.exports = {
  name: "set-response",
  description: "Auto Response List.",
  category: "Setup",
  userPerms: ["ManageChannels"],
  botPerms: ["ManageChannels"],
  aliases: ["acr"],
  execute: async (message, args, client, prefix) => {
    if(!message.member.permissions.has("ManageGuild")) {
      const warning = new EmbedBuilder()
      .setColor("#b30000")
      .setDescription("<a:warning:1004256966224388106>➜ You don't have permission to use this commands!")
      return message.reply({ embeds: [warning] });
    }
    const guildDB = await Guild.findOne({
      guildId: message.guild.id,
    });
    const namee = args[0];

    if (!namee)
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setDescription(
              `_\`\`\`asciidoc\nUsage: ${prefix}set-response <text-name> <text-reply>\n\nExample: ${prefix}set-response <ping> <pong>.\`\`\`_`
            )
            .setColor(client.embedColor)
        ],
      });

    let name = namee.toLowerCase();
    const content = args.slice(1).join(" ");
    if (!content)
      return message.reply({
        embeds: [
          new EmbedBuilder()
          .setDescription(
            `_\`\`\`asciidoc\n${prefix}set-response <text-name> <text-reply>\n\nExample: ${prefix}set-response <ping> <pong>.\`\`\`_`
          )
          .setColor(client.embedColor)
        ],
      });

    if (namee.length > 30)
      return message.reply(
        `\`\`\`asciidoc\n⚠️➜ An Error Occured!\`\`\``
      );
    if (content.length > 2000)
      return message.reply(
        `\`\`\`asciidoc\n⚠️➜ An Error Occured!\`\`\``
      );


      const conditional = {
        guildId: message.guild.id,
      };
      const results = await autoResponse.find(conditional);

      if (results.length >= 30) {
        message.channel.reply({
          embeds: [
            new EmbedBuilder()
              .setColor("#b30000")
              .setDescription(
                `\`\`\`asciidoc\n⚠️➜ Auto Response Limit Reached (30).\`\`\``
              ),
          ],
        });

        return;
      }
    autoResponse.findOne(
      {
        guildId: message.guild.id,
        name,
      },
      async (err, data) => {
        if (!data) {
          autoResponse.create({ guildId: message.guild.id, name, content });
          message.reply({
            embeds: [
              new EmbedBuilder()
              .setDescription(`<a:correct:1004239653072801922>➜ ***Successfully added text \`[ ${name} ].\`***`)
              .setColor(client.embedColor)
            ],
          });
        } else {
          return message.reply(
            `\`\`\`asciidoc\n⚠️➜ The Auto Response already exists!\`\`\``
          );
        }
      }
    );
  }
};