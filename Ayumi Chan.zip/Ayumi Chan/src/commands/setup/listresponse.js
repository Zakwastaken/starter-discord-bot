const { EmbedBuilder } = require("discord.js");
const autoResponse = require("../../schema/autoresponse");
module.exports = {
    name: "list-response",
    aliases: ["lcr"],
    description: "Auto Response List.",
    category: "Setup",
    userPerms: ["ManageChannels"],
    botPerms: ["ManageChannels"],
    execute: async (message, args, client, prefix) => {
      if(!message.member.permissions.has("ManageGuild")) {
        const warning = new EmbedBuilder()
        .setColor("#b30000")
        .setDescription("<a:warning:1004256966224388106>➜ You don't have permission to use this commands!")
        return message.reply({ embeds: [warning] });
      }
    autoResponse.find(
      {
        guildId: message.guild.id,
      },
      (err, data) => {
        if (!data && !data.name)
          return message.reply(
            `\`\`\`asciidoc\n⚠️➜ An Error Occured!\`\`\``
          );
        let array = [];
        data.map((d, i) => array.push(d.name));

        let embed = new EmbedBuilder()
        .setColor(client.embedColor)
          .setDescription(array.join(" ・ "))
          .setFooter({ text: `${message.guild.name} Text List.` });

        if (!Array.isArray(array) || !array.length) {
          embed.setDescription(`\`\`\`asciidoc\n⚠️➜ Empty!\`\`\``);
        } else {
          embed.setDescription(`\`\`\`asciidoc\n${array.join(" ・ ")}\`\`\``);
        }

        message.reply({ embeds: [embed] });
      }
    );
  }
};