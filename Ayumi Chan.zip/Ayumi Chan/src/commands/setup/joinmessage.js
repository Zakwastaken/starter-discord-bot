const prefixModel = require("../../schema/joinmsg");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "setmessage",
  description: "Change the welcome message per server!",
  aliases: ["joinmsg", "welcomemsg", "jmsg"],
  category: "Setup",
  userPerms: ["ManageChannels"],
  botPerms: ["ManageChannels"],
  execute: async (message, args, client, prefix) => {
    if(!message.member.permissions.has("ManageGuild")) {
        const warning = new EmbedBuilder()
        .setColor("#b30000")
        .setDescription("<a:warning:1004256966224388106>➜ You don't have permission to use this commands!")
        return message.reply({ embeds: [warning] });
      }
    const text = args.join(" ");
    if (!args[0]) {
      return message.reply(`_\`\`\`asciidoc\nUsage: ${prefix}welcome-message <Text|off> !\`\`\`_`);
    }
    if (text !== "off") {
      const data = await prefixModel.findOne({
        GuildID: message.guild.id,
      });

      if (data) {
        await prefixModel.findOneAndRemove({
          GuildID: message.guild.id,
        });
        let newData = new prefixModel({
          JoinMsg: args.join(" "),
          GuildID: message.guild.id,
        });
        newData.save();
        const warning2 = new EmbedBuilder()
        .setColor(client.embedColor)
        .setDescription(`<a:correct:1004239653072801922>➜ **Join Message set to ${newData.JoinMsg}.**`)
        return message.reply({ embeds: [warning2] });
      } else if (!data) {
        let newData = new prefixModel({
          JoinMsg: args.join(" "),
          GuildID: message.guild.id,
        });
        newData.save();
        const warning4 = new EmbedBuilder()
        .setColor(client.embedColor)
        .setDescription(`<a:correct:1004239653072801922>➜ **Join Message set to ${newData.JoinMsg}.**`)
        return message.reply({ embeds: [warning4] });
      }
    } else if (text === "off") {
      const data2 = await prefixModel.findOne({
        GuildID: message.guild.id,
      });

      if (data2) {
        await prefixModel.findOneAndRemove({
          GuildID: message.guild.id,
        });
        const warning5 = new EmbedBuilder()
        .setColor(client.embedColor)
        .setDescription(`<a:correct:1004239653072801922>➜ ***Join Message has been turned off!***`)
        return message.reply({ embeds: [warning5] });
      } else if (!data2) {
        const warning6 = new EmbedBuilder()
        .setColor("#b30000")
        .setDescription(`<a:warning:1004256966224388106>➜ ***Join Message isn't setup!***`)
        return message.reply({ embeds: [warning6] });
      }
    }
  },
};