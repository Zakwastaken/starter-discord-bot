const prefixModel = require("../../schema/leavechannel");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "leave-channel",
  description: "Change the goodbye channel per server!",
  aliases: ["lchannel", "goodbye"],
  category: "Setup",
  userPerms: ["ManageChannels"],
  botPerms: ["ManageChannels"],

  execute: async (message, args, client, prefix) => {
    if(!message.member.permissions.has("ManageGuild")) {
      const warning = new EmbedBuilder()
      .setColor("#b30000")
      .setDescription("<a:warning:1004256966224388106>➜ You don't have permission to use this commands!")
      return message.reply({ embeds: [warning] });
    }
    if (!args[0]) {
      return message.reply(`_\`\`\`ascidoc\nUsage: ${prefix}leave-channel <#channel|off> !\`\`\`_`);
    }
    if (message.mentions.channels.first()) {
      const data = await prefixModel.findOne({
        GuildID: message.guild.id,
      });

      if (data) {
        await prefixModel.findOneAndRemove({
          GuildID: message.guild.id,
        });
        const warning2 = new EmbedBuilder()
        .setColor(client.embedColor)
        .setDescription(`<a:correct:1004239653072801922>➜ ***Leave Channel set to ${message.mentions.channels.first()}.***`)
         message.reply({ embeds: [warning2] });
        
        let newData = new prefixModel({
          Bye: message.mentions.channels.first().id,
          GuildID: message.guild.id,
        });
        newData.save();
      } else if (!data) {
        const warning4 = new EmbedBuilder()
        .setColor(client.embedColor)
        .setDescription(`<a:correct:1004239653072801922>➜ ***Leave Channel set to ${message.mentions.channels.first()}.***`)
         message.reply({ embeds: [warning4] });

        let newData = new prefixModel({
          Bye: message.mentions.channels.first().id,
          GuildID: message.guild.id,
        });
        newData.save();
      }
    } else if (args[0] === "off") {
      const data2 = await prefixModel.findOne({
        GuildID: message.guild.id,
      });

      if (data2) {
        await prefixModel.findOneAndRemove({
          GuildID: message.guild.id,
        });
        const warning5 = new EmbedBuilder()
        .setColor(client.embedColor)
        .setDescription(`<a:correct:1004239653072801922>➜ ***Leave channel has been turned off!***`)
         message.reply({ embeds: [warning5] });
      } else if (!data2) {
        const warning6 = new EmbedBuilder()
        .setColor("#b30000")
        .setDescription(`<a:warning:1004256966224388106>➜ ***Leave channel isn't setup!***`)
         message.reply({ embeds: [warning6] });
      }
    }
  },
};