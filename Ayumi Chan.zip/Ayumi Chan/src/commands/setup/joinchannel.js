const prefixModel = require("../../schema/welcome");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "setwelcome",
  description: "Change the welcome channel per server!",
  aliases: ["jchannel", "welcome"],
  category: "Setup",
  userPerms: ["ManageChannels"],
  botPerms: ["ManageChannels"],
  execute: async (message, args, client, prefix) => {
    if(!message.member.permissions.has("ManageGuild")) {
      const warning = new EmbedBuilder()
      .setColor("#b30000")
      .setDescription("<a:warning:1004256966224388106>➜ You don't have permission to use this commands!")
      return message.reply({ embeds: [warning] });
    }
    if (!args[0]) {
      return message.reply(`_\`\`\`asciidoc\nUsage: ${prefix}setwelcome <#channel|off> !\`\`\`_`);
    }
    if (message.mentions.channels.first()) {
      const data = await prefixModel.findOne({
        GuildID: message.guild.id,
      });

      if (data) {
        await prefixModel.findOneAndRemove({
          GuildID: message.guild.id,
        });
        const embed = new EmbedBuilder()
        .setColor(client.embedColor)
        .setDescription(`<a:correct:1004239653072801922>➜ ***Join Channel set to ${message.mentions.channels.first()}.***`)
         message.reply({ embeds: [embed] });

        let newData = new prefixModel({
          Welcome: message.mentions.channels.first().id,
          GuildID: message.guild.id,
        });
        newData.save();
      } else if (!data) {
        const embed2 = new EmbedBuilder()
        .setColor(client.embedColor)
        .setDescription(`<a:correct:1004239653072801922>➜ ***Join Channel set to ${message.mentions.channels.first()}.***`)
         message.reply({ embeds: [embed2] });

        let newData = new prefixModel({
          Welcome: message.mentions.channels.first().id,
          GuildID: message.guild.id,
        });
        newData.save();
      }
    } else if (args[0] === "off") {
      const data2 = await prefixModel.findOne({
        GuildID: message.guild.id,
      });

      if (data2) {
        await prefixModel.findOneAndRemove({
          GuildID: message.guild.id,
        });
        const embed3 = new EmbedBuilder()
        .setColor(client.embedColor)
        .setDescription(`<a:correct:1004239653072801922>➜ ***Join channel has been turned off!***`)
         message.reply({ embeds: [embed3] });
      } else if (!data2) {
        const embed4 = new EmbedBuilder()
        .setColor("#b30000")
        .setDescription(`<a:warning:1004256966224388106>➜ ***Join channel isn't setup!***`)
         return message.reply({ embeds: [embed4] });
      }
    }
  },
};