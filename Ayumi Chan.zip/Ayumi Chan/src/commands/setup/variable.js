const { EmbedBuilder } = require("discord.js");

module.exports = {
    name: "variable",
    category: "Setup",
    description: "Show Message Variables Setup.",
    aliases: ["var"],

    execute: async (message, args, client, prefix) => {
        if(!message.member.permissions.has("ManageGuild")) {
            const warning = new EmbedBuilder()
            .setColor("#b30000")
            .setDescription("<a:warning:1004256966224388106>➜ You don't have permission to use this commands!")
            return message.reply({ embeds: [warning] });
          }
        let embed = new EmbedBuilder()
        .setAuthor({ name: "Content Setting.", iconURL: client.user.displayAvatarURL()})
        .setDescription("_\`\`\`asciidoc\nHere below how to set the [ welcome ] and [ goodbye ] message you want and follow the steps below.\`\`\`_")

        .addFields({ name: `<:line2:972782869481144340> ***#Variables:***`, value: `\`\`\`asciidoc\n{user.mention} - Mentions the User (ex. @Zakuro)\n{user.name} - The User Tag (ex. Zakuro#0646)\n{server} - Guilds Name (ex. WEEBOO ID)\n{membercount} - Guilds Member Count (ex. 4,000)\`\`\``},
                   { name: `<:line:972780438118629386> ***#Example:***`, value: `\`\`\`asciidoc\nHello {user.mention}, Welcome to {server}\`\`\``})
        .setFooter({
            text: "© PT Wibu Cahaya Asia 2022"
            })
        .setImage("https://cdn.discordapp.com/attachments/999994143029870622/1037215168960135168/general___Emoji_Server_-_Discord_02_11_2022_11_02_00_2.png")
        .setTimestamp()
        .setColor(client.embedColor)
        return message.reply({embeds: [embed]})
    }}