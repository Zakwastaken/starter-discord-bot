const { EmbedBuilder } = require("discord.js");
const autoResponse = require("../../schema/autoresponse");
const Guild = require("../../schema/guild");
module.exports = {
  name: "delete-response",
  description: "Auto Response Delete.",
  category: "Setup",
  userPerms: ["ManageChannels"],
  botPerms: ["ManageChannels"],
  aliases: ["dcr"],
  execute: async (message, args, client, prefix) => {
    if(!message.member.permissions.has("ManageGuild")) {
      const warning = new EmbedBuilder()
      .setColor("#b30000")
      .setDescription("<a:warning:1004256966224388106>➜ You don't have permission to use this commands!")
      return message.reply({ embeds: [warning] });
    }
    const guildDB = await Guild.findOne({
      guildId: message.guild.id,
    });
    const name = args[0];

    if (!name)
      return message.reply({
          embeds: [
            new EmbedBuilder()
              .setDescription(
                `_\`\`\`asciidoc\nUsage: ${prefix}delete-response <text-name>\n\nExample: ${prefix}delete-response <pog>.\`\`\`_`
              )
              .setColor(client.embedColor)
          ],
        })

    if (name.length > 30)
      return message.reply(
        `\`\`\`asciidoc\n⚠️➜ An Error Occured!\`\`\``
      );

    autoResponse.findOne(
      {
        guildId: message.guild.id,
        name,
      },
      async (err, data) => {
        if (data) {
          data.delete({ guildId: message.guild.id, name });
          message.reply({
            embeds: [
              new EmbedBuilder()
              .setColor(client.embedColor)
                .setDescription(`<a:correct:1004239653072801922>➜ ***Successfully deleted text \`[ ${name} ].\`***`)
            ],
          });
        } else {
          message.reply(
            `\`\`\`asciidoc\n⚠️➜ The Auto Response not exists!\`\`\``
          );
        }
      }
    );
  }
};