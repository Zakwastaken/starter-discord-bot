const { ChannelType, EmbedBuilder } = require('discord.js');
const moment = require('moment');

module.exports = {
  name: "guildCreate",
  run: async (client, guild) => {

    const channel = client.channels.cache.get(client.config.logs);
    let own = await guild?.fetchOwner();
    let text;
    guild.channels.cache.forEach(c => {
      if (c.type === ChannelType.GuildText && !text) text = c;
    });
    const embed = new EmbedBuilder()
      .setColor(client.embedColor)
      .setThumbnail(guild.iconURL({ size: 1024 }))
      .setDescription(`<:right:982194328522854410>・Join Server **${guild.name}** (\`${guild.id}\`)\n<:line:972780438118629386>・${client.guilds.cache.size} Servers with ${guild.memberCount.toLocaleString()} Users.`)
    channel.send({ embeds: [embed] });
  }

};
