const { EmbedBuilder } = require('discord.js');
const moment = require('moment');

module.exports = {
  name: "guildDelete",
  run: async (client, guild) => {

    const channel = client.channels.cache.get(client.config.logs);
    let own = await guild?.fetchOwner()
    let text;
    guild.channels.cache.forEach(c => {
      if (c.type === "GUILD_TEXT" && !text) text = c;
    });
    const embed = new EmbedBuilder()
      .setThumbnail(guild.iconURL({ dynamic: true, size: 1024 }))
      .setColor("#b30000")
      .setThumbnail(guild.iconURL({ size: 1024 }))
      .setDescription(`<:left:982194302476247090>・Leave Server **${guild.name}** (\`${guild.id}\`)\n<:line:972780438118629386>・${client.guilds.cache.size} Servers with ${guild.memberCount.toLocaleString()} Users.`)
    channel.send({ embeds: [embed] });
  }
}
