const { prefix } = require("../../configg.js");
const { Activity, ActivityType } = require("discord.js");

module.exports ={
    name: "ready",
    run: async (client) => {
        let api_ping = client.ws.ping;
        client.manager.init(client.user.id);
        client.logger.log(`${client.user.username} online!`, "ready");
        client.logger.log(`Ready on ${client.guilds.cache.size} servers, for a total of ${client.guilds.cache.reduce((a, g) => a + g.memberCount, 0)} users`, "ready");
    
    let statuses = [`Your Heart's 💚 | Ping ${api_ping} ms`];
    setInterval(function() {
  		let status = statuses[Math.floor(Math.random()*statuses.length)];
  		client.user.setActivity(status, {type: ActivityType.Listening});
  	}, 10000)
 }}