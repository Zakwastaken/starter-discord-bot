const { EmbedBuilder, Message, Client, PermissionsBitField } = require("discord.js");
const db = require("../../schema/prefix.js");
const db2 = require("../../schema/dj");
const db3 = require("../../schema/setup");
const Discord = require('discord.js')
const cooldowns = new Map()
const ms = require('ms');

module.exports = {
    name: "messageCreate",
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @returns 
     */
    run: async (client, message) => {

        const emojiwarn = client.emoji.warn;;

        if (message.author.bot) return;
        
        let prefix = client.prefix;
        const ress = await db.findOne({ Guild: message.guildId })
        if (ress && ress.Prefix) prefix = ress.Prefix;
        let data = await db3.findOne({ Guild: message.guildId });
        if (data && data.Channel && message.channelId === data.Channel) return client.emit("setupSystem", message);

        const mention = new RegExp(`^<@!?${client.user.id}>( |)$`);
        if (message.content.match(mention)) {
            const embed = new EmbedBuilder()
                .setColor(client.embedColor)
                .setDescription(`**My prefix in this server is \`${prefix}\`**\n**You can see my all commands type \`${prefix}\`help**`);
            message.channel.send({ embeds: [embed] })
        };
        const escapeRegex = (str) => str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

        const prefixRegex = new RegExp(`^(<@!?${client.user.id}>|${escapeRegex(prefix)})\\s*`);
        if (!prefixRegex.test(message.content)) return;

        const [matchedPrefix] = message.content.match(prefixRegex);

        const args = message.content.slice(matchedPrefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();

        const command = client.commands.get(commandName) ||
            client.commands.find((cmd) => cmd.aliases && cmd.aliases.includes(commandName));

        if (!command) return;

        if (!message.guild.members.me.permissions.has(PermissionsBitField.resolve('SendMessages'))) return await message.author.dmChannel.send({ content: `I don't have **\`SEND_MESSAGES\`** permission in <#${message.channelId}> to execute this **\`${command.name}\`** commands!` }).catch(() => { });

        if (!message.guild.members.me.permissions.has(PermissionsBitField.resolve('ViewChannel'))) return;

        if (!message.guild.members.me.permissions.has(PermissionsBitField.resolve('EmbedLinks'))) return await message.channel.send({ content: `I don't have **\`EMBED_LINKS\`** permission in <#${message.channelId}> to execute this **\`${command.name}\`** commands!` }).catch(() => { });

        const embed = new EmbedBuilder()
            .setColor('#b30000')

        if (command.args && !args.length) {
            let reply = `${emojiwarn}*➜ You didn't provide any arguments, ${message.author}!*`;

            if (command.usage) {
                reply += `\n\`\`\`asciidoc\nUsage: ${prefix}${command.name} ${command.usage}\`\`\``;
            }

            embed.setDescription(reply);
            return message.channel.send({ embeds: [embed] });
        }

        if (command.botPerms) {
            if (!message.guild.members.me.permissions.has(PermissionsBitField.resolve(command.botPerms || []))) {
                embed.setDescription(`${emojiwarn}*➜ I don't have permission in <#${message.channelId}> to execute this **\`${command.name}\`** commands!*`);
                return message.channel.send({ embeds: [embed] });
            }
        }
        if (command.userPerms) {
            if (!message.member.permissions.has(PermissionsBitField.resolve(command.userPerms || []))) {
                embed.setDescription(`${emojiwarn}*➜ You don't have permission in <#${message.channelId}> to execute this **\`${command.name}\`** commands!*`);
                return message.channel.send({ embeds: [embed] });
            }
        }

        if (command.owner && message.author.id !== `${client.owner}`) {
            embed.setDescription(`${emojiwarn}*➜ Only <@760723665372971008> can use this commands!*`);
            return message.channel.send({ embeds: [embed] });
        }

        const player = message.client.manager.get(message.guild.id);

        if (command.player && !player) {
            embed.setDescription(`${emojiwarn}*➜ There is no player for this guild.*`);
            return message.channel.send({ embeds: [embed] });
        }

        if (command.inVoiceChannel && !message.member.voice.channelId) {
            embed.setDescription(`${emojiwarn}*➜ You must be in a voice channel!*`);
            return message.channel.send({ embeds: [embed] });
        }

        if (command.sameVoiceChannel) {
            if (message.guild.members.cache.get(client.user.id).voice.channel) {
                if (message.guild.members.cache.get(client.user.id).voice.channelId !== message.member.voice.channelId) {
                    embed.setDescription(`${emojiwarn}*➜ You must be in the same channel as ${message.client.user}!*`);
                    return message.channel.send({ embeds: [embed] });
                }
            }
        }
        if (command.dj) {
            let data = await db2.findOne({ Guild: message.guild.id })
            let perm = 'MuteMembers';
            if (data) {
                if (data.Mode) {
                    let pass = false;
                    if (data.Roles.length > 0) {
                        message.member.roles.cache.forEach((x) => {
                            let role = data.Roles.find((r) => r === x.id);
                            if (role) pass = true;
                        });
                    };
                    if (!pass && !message.member.permissions.has(perm)) return message.channel.send({ embeds: [embed.setDescription(`${emojiwarn}*➜ You don't have permission or dj role to use this commands!*`)] })
                };
            };
        }
        if (command) {

            if (!cooldowns.has(command.name)) {
        
                cooldowns.set(command.name, new Discord.Collection())
        
            }
        
            const currentTime = Date.now()
            const timeStamps = cooldowns.get(command.name)
            const cooldownAmount = (command.cooldown) * 1000
        
            if (timeStamps.has(message.author.id)) {
        
                const expTime = timeStamps.get(message.author.id) + cooldownAmount
        
                if (currentTime < expTime) {
        
                    const timeLeft = (expTime - currentTime) / 1000
        
                    const tmotEmbed = new EmbedBuilder()
                    .setColor("#b30000")
                    .setDescription(`<a:timer:1044486802351861880>➜ **You must wait** **\`${timeLeft.toFixed(1)}\`** **more seconds before using** **\`${command.name}.\`**`)
        
                    return message.reply({ embeds: [tmotEmbed] }).then((msg) => {
                        let time = "5s";
                        setTimeout(function () {
                          msg.delete();
                        }, ms(time));
                      });
                }

            }
        
            timeStamps.set(message.author.id, currentTime)
        
            setTimeout(() => {
                timeStamps.delete(message.author.id)
            }, cooldownAmount)
        }
        try {
            command.execute(message, args, client, prefix);
        } catch (error) {
            console.log(error);
            embed.setDescription("\`\`\`asciidoc\nThere was an error executing that commands!\`\`\`");
            return message.channel.send({ embeds: [embed] });
        }
    }
};